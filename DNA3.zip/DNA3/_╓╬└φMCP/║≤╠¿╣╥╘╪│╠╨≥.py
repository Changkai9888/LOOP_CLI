# 文件名: 后台挂载程序.py
"""
文件名: daemon_manager.py
前台守护进程管理器

核心功能：
1. 启动监控：使用沙箱模式（run_sandbox_detached）启动指定的Python脚本作为后台守护进程
2. 自动重试：如果启动失败，采用指数退避策略（1,2,4,8秒）最多重试5次
3. 健康监控：每2秒检查后台进程状态，如意外退出（返回码≠0）立即重启
4. 定期维护：每N秒（默认600秒/10分钟）强制重启，清理资源并刷新进程状态
5. 彻底清理：主程序退出时，确保杀死整个后台进程树，避免孤儿进程残留

设计特点：
- 前后台完全隔离：后台进程的所有输出被重定向，不会污染前台控制台
- 进程树级清理：通过进程组（Unix）或taskkill /T（Windows）确保彻底清理
- 线程安全：使用锁机制防止对进程变量的并发访问冲突
- 优雅退出：通过atexit和信号处理，确保几乎所有退出路径都能触发清理

使用方式：
1. 修改main()函数中的BACKEND_SCRIPT变量，指向您的后台脚本
2. 直接运行本程序：python daemon_manager.py
3. 按下Ctrl+C可安全退出，后台进程会被自动清理
"""
import os
import sys
import time
import signal
import atexit
import threading
from typing import Optional, Tuple
from run_py_sandbox import run_sandbox_detached, _kill_process_tree  # 导入您提供的模块

class DaemonManager:
    def __init__(self, daemon_script_path: str, restart_interval: int = 600):
        """
        初始化管理器。

        :param daemon_script_path: 要作为守护进程运行的Python脚本的**绝对路径**。
        :param restart_interval: 定期强制重启的间隔时间（秒）。默认为600秒（10分钟）。
        """
        self.daemon_script = daemon_script_path
        self.restart_interval = restart_interval
        self.proc: Optional[subprocess.Popen] = None
        self.pid: Optional[int] = None
        self.manager_active = threading.Event()  # 用于控制监控和重启循环
        self.manager_active.set()
        self.restart_timer: Optional[threading.Timer] = None
        self.monitor_thread: Optional[threading.Thread] = None
        self.lock = threading.Lock()  # 防止对进程变量的并发访问

    def _start_daemon_with_retry(self) -> bool:
        """
        启动守护进程，附带指数退避重试机制。
        返回True表示启动成功，False表示达到最大重试次数后仍失败。
        """
        max_retries = 5
        base_delay = 1  # 初始延迟1秒
        for attempt in range(max_retries):
            with self.lock:
                # 启动前，先清理可能残留的进程 (安全操作)
                if self.pid and self.pid != os.getpid():
                    _kill_process_tree(self.pid)
                self.proc, self.pid, _ = run_sandbox_detached(self.daemon_script)
            
            if self.proc and self.pid:
                print(f"[管理器] 后台守护进程启动成功。PID: {self.pid} (尝试次数: {attempt+1})")
                return True
            else:
                if attempt < max_retries - 1:
                    wait_time = base_delay * (2 ** attempt)  # 指数退避：1, 2, 4, 8...
                    print(f"[管理器] 启动失败，{wait_time}秒后重试... (第{attempt+1}次)")
                    time.sleep(wait_time)
                else:
                    print(f"[管理器] 错误：启动后台进程失败，已尝试{max_retries}次。")
        return False

    def _monitor_and_restart_loop(self):
        """监控与重启的主循环，运行在独立线程中。"""
        # 1. 首次启动
        if not self._start_daemon_with_retry():
            print("[管理器] 初始启动失败，监控循环退出。")
            return

        # 2. 启动成功后，设置第一次定时重启
        self._schedule_periodic_restart()

        # 3. 进入健康检查循环
        while self.manager_active.is_set():
            time.sleep(2)
            with self.lock:
                if self.proc is None:
                    continue
                
                returncode = self.proc.poll()
                if returncode is not None:
                    # 修改这里：只有非0返回码才立即重启
                    if returncode != 0:
                        print(f"[管理器] 警告：后台进程 (PID: {self.pid}) 异常退出，返回码 {returncode}。立即重启...")
                        if self.restart_timer:
                            self.restart_timer.cancel()
                        self._perform_restart()
                        self._schedule_periodic_restart()
                    else:
                        # 正常退出，不清除进程对象，等待定时重启
                        print(f"[管理器] 后台进程正常完成 (返回码: 0)。等待下次定时重启。")
                        self.proc = None
                        self.pid = None

    def _schedule_periodic_restart(self):
        """安排下一次定期重启。"""
        if not self.manager_active.is_set():
            return
        with self.lock:
            if self.restart_timer:
                self.restart_timer.cancel()
            self.restart_timer = threading.Timer(self.restart_interval, self._perform_restart)
            self.restart_timer.daemon = True
            self.restart_timer.start()
            print(f"[管理器] 已安排 {self.restart_interval} 秒后的定期重启。")

    def _perform_restart(self):
        """执行重启操作：杀死旧进程，启动新进程。"""
        print("[管理器] 执行重启操作...")
        with self.lock:
            old_pid = self.pid
            if old_pid:
                print(f"[管理器] 正在终止旧进程树 (PID: {old_pid})...")
                _kill_process_tree(old_pid)
                # 等待一小段时间，确保系统资源释放
                time.sleep(0.5)
            # 启动新进程
            if not self._start_daemon_with_retry():
                print("[管理器] 重启失败！将在下次监控循环中重试。")
            # 注意：_schedule_periodic_restart 会在监控循环或本函数外部被调用，
            # 这里不需要重复调用，否则会导致定时器嵌套。

    def _cleanup(self):
        """清理函数：停止所有活动，并杀死后台进程。"""
        print("\n[管理器] 正在执行退出清理...")
        self.manager_active.clear()  # 通知监控循环停止

        with self.lock:
            # 取消定时器
            if self.restart_timer:
                self.restart_timer.cancel()
            # 杀死后台进程
            if self.pid:
                print(f"[管理器] 终止后台进程树 (PID: {self.pid})...")
                _kill_process_tree(self.pid)
                self.pid = None
                self.proc = None
        print("[管理器] 清理完成。")

    def start(self):
        """启动守护进程管理器。"""
        print(f"[管理器] 启动守护进程管理器，目标脚本: {self.daemon_script}")
        print(f"[管理器] 定期重启间隔: {self.restart_interval} 秒")
        
        # 启动监控线程
        self.monitor_thread = threading.Thread(target=self._monitor_and_restart_loop, daemon=True)
        self.monitor_thread.start()
        print("[管理器] 监控线程已启动。")

    def stop(self):
        """停止守护进程管理器。"""
        self._cleanup()
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5.0)
        print("[管理器] 已停止。")

def run_BACKEND_SCRIPT(BACKEND_SCRIPT):
    """主函数，演示如何使用管理器。"""
    # ==== 配置部分 ====
    # 请将以下路径替换为您实际的后台守护进程脚本的**绝对路径**
    # 例如: BACKEND_SCRIPT = r"C:\Users\lck_N150\Documents\my_daemon.py"
    #BACKEND_SCRIPT = r"C:\YOUR\FULL\PATH\TO\your_background_daemon.py"
    
    RESTART_INTERVAL = 600  # 重启间隔（秒），10分钟

    if not os.path.exists(BACKEND_SCRIPT):
        print(f"错误：找不到后台脚本 '{BACKEND_SCRIPT}'")
        print("请修改 `daemon_manager.py` 中 `run_BACKEND_SCRIPT()` 函数里的 `BACKEND_SCRIPT` 变量。")
        sys.exit(1)

    # ==== 创建并启动管理器 ====
    manager = DaemonManager(BACKEND_SCRIPT, RESTART_INTERVAL)
    
    # 注册退出时的清理函数
    atexit.register(manager.stop)
    # 捕获常见终止信号，确保清理函数被调用
    signal.signal(signal.SIGINT, lambda sig, frame: sys.exit(0))  # Ctrl+C
    signal.signal(signal.SIGTERM, lambda sig, frame: sys.exit(0)) # 系统终止信号
    
    manager.start()
    
    # ==== 主程序（前台）继续做其他事情... ====
    print("\n" + "="*50)
    print("前台主程序正在运行。")
    print("按下 Ctrl+C 可终止程序并清理后台进程。")
    print("="*50)
    
    try:
        # 这里可以替换成您主程序需要执行的任何其他任务
        # 示例：一个简单的保持前台运行的空循环
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n收到中断信号，程序即将退出...")
    finally:
        # manager.stop() 已通过 atexit 注册，会自动调用
        pass

if __name__ == "__main__":
    BACKEND_SCRIPT=r'C:\Users\lck_N150\Documents\GitHub\lck-code\Loop-CLI闭环自激演化系统\20260513DS工作文件夹\DNA3\_摘要中枢\_目录更新自动生成监视.py'
    run_BACKEND_SCRIPT(BACKEND_SCRIPT)
