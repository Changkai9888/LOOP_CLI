# 文件名：run_sandbox.py
import os
import signal
import subprocess
import sys

def _kill_process_tree(pid):
    """
    终止指定进程及其子进程/孙进程。
    Win10 使用 taskkill /T /F；其他系统使用进程组方式。
    """
    if os.name == "nt":
        subprocess.run(
            ["taskkill", "/PID", str(pid), "/T", "/F"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
    else:
        try:
            os.killpg(os.getpgid(pid), signal.SIGKILL)
        except ProcessLookupError:
            pass


def run_sandbox(script_path, timeout=None, input_provider=None):
    """
    在沙箱子进程中运行 Python 脚本。

    :param script_path: 要运行的 Python 文件路径
    :param timeout: 超时时间，防止阻塞
    :param input_provider: 可选函数，后续可扩展为由大模型生成 stdin
    :return: (success, stdout, stderr)
    """
    if timeout is None:
        timeout=30
    timeout=max(10,timeout)
    if not os.path.exists(script_path):
        return False, "", f"文件不存在: {script_path}"

    if input_provider is None:
        input_provider = lambda prompt="": "\n"

    stdin_text = input_provider()
    if stdin_text is None:
        stdin_text = ""
    if not stdin_text.endswith("\n"):
        stdin_text += "\n"

    popen_kwargs = {
        "args": [sys.executable, script_path],
        "stdin": subprocess.PIPE,
        "stdout": subprocess.PIPE,
        "stderr": subprocess.PIPE,
        "text": True,
    }

    # 非 Windows 下创建新进程组，方便超时后杀整棵进程树。
    if os.name != "nt":
        popen_kwargs["preexec_fn"] = os.setsid
    else:
        popen_kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP

    proc = subprocess.Popen(**popen_kwargs)

    try:
        stdout, stderr = proc.communicate(input=stdin_text, timeout=timeout)
        success = proc.returncode == 0
        return success, stdout, stderr

    except subprocess.TimeoutExpired:
        _kill_process_tree(proc.pid)

        try:
            stdout, stderr = proc.communicate(timeout=3)
        except subprocess.TimeoutExpired:
            stdout, stderr = "", ""

        timeout_msg = f"程序执行超时 timeout={timeout}，已终止该进程及其子进程/孙进程。"
        if stderr:
            stderr = stderr.rstrip() + "\n" + timeout_msg
        else:
            stderr = timeout_msg

        return False, stdout, stderr

    except Exception as e:
        _kill_process_tree(proc.pid)
        return False, "", f"执行过程中发生异常: {e}"


def main():
    script_path = input("请输入要运行的 Python 文件路径: ").strip()

    success, stdout, stderr = run_sandbox(script_path)

    print("\n=== 运行结果 ===")
    if stdout:
        print("标准输出:\n", stdout)
    if stderr:
        print("错误输出:\n", stderr)
    print("执行成功：", success)


if __name__ == "__main__":
    main()
