# -*- coding: utf-8 -*-
from _unifiedAPI import *
import json,traceback, os, time ,sys,psutil, multiprocessing
from datetime import datetime
from _提示词合成器 import get_system_prompt
from _治理MCP.run_py_sandbox import run_sandbox
from _守护进程 import start_daemon
############
from _print_AI_reply import print_AI_reply, call_api
####
IS_CMD = psutil.Process(os.getppid()).name().lower() in ("cmd.exe", "powershell.exe", "pwsh.exe")         # ✅ 是否在真实终端（CMD/WT）
if IS_CMD:
    os.system("")          # 激活 CMD 的 ANSI； CmD里设置颜色。
    from colorama import init, Fore, Back, Style
    init(autoreset=True)
log_dir = "_治理日志"
os.makedirs(log_dir, exist_ok=True)
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
timestamp_file = os.path.join(log_dir, f"_dialog_{timestamp}.json")
latest_file = os.path.join(log_dir, "_latest.json")
###########
def print_cmd(text, color='CYAN', end="\n"):
    if IS_CMD:
        color_list={'CYAN':Fore.CYAN, 'LIGHTGREEN_EX':Fore.LIGHTGREEN_EX}
        print(color_list[color] + text, end=end)
    else:
        print(text)
def print_AI_reply(AI_reply_display, token_usage):#token_usage=response['tokens']#打印ai回复。
    if AI_reply_display:
        print_cmd('[AI回答]: ', color='LIGHTGREEN_EX', end='')
        print(AI_reply_display)
    print_cmd(f"[Token使用]: 提示词{token_usage['prompt_tokens']}, 补全{token_usage['completion_tokens']}, 总计{token_usage['total_tokens']}")
    return
call_api_old=call_api
def call_api( *args, stat='/', **kwargs):
    #kwargs["model"] = "deepseek-v4-flash"
    print("[AI]: 思考中...");
    err=''#记录错误信息
    try:
        response=call_api_old(*args, **kwargs)
    except Exception as err_new:
        err+=str(err_new)
    user_prompt, system_prompt = response["prompt"]  # 从响应中获取提示词，若无则用默认值
    user_entry = {
        "role": "user",
        "content": args[0],
        "timestamp": datetime.now().isoformat()
    }
    ai_entry = {
        "role": "assistant",
        "content": response["result"].get("answer") if isinstance(response["result"], dict) else response["result"],
        "reasoning": response["result"].get("reasoning") if isinstance(response["result"], dict) else None,
        "tokens": response["tokens"],
        "timestamp": datetime.now().isoformat()
    }
    conversation_round = {
        "user": user_entry,
        "prompts": {  # 新增：记录提示词
            "user_prompt": user_prompt,  # 最终传给API的用户提示词
            "system_prompt": system_prompt     # 系统提示词
                    },
        "assistant": ai_entry,
        "errption": '本轮发生报错，错误信息为: '+err if err else '本轮未报错。'
    }
    with open(timestamp_file, 'a', encoding='utf-8') as f:
        json.dump(conversation_round, f, ensure_ascii=False);f.write('\n')
    with open(latest_file, 'a', encoding='utf-8') as f:
        json.dump(conversation_round, f, ensure_ascii=False);f.write('\n')
    return response

###########
print(f"AI对话系统已启动")
print(f"时间戳日志: {timestamp_file}")
print(f"最新日志: {latest_file}")
print("输入 'exit' 或 'quit' 结束对话\n")
#############
re=input('是否恢复上次的对话记录？(y/n)')
# main.py (测试主程序入口)
from _打印信息管理 import start_console_capture, get_captured_logs, stop_console_capture
start_console_capture("./_治理日志", "_dialogue_history.log")
#####劫持前台进程所有的打印。
if re.strip().lower() in ('y', 'yes'):
    with open('_治理日志/_dialogue_history.log', 'r', encoding='utf-8') as f: dialogue_history = f.read()
    dialogue_count =int(dialogue_history.count("[AI回答]"))
    print('\n[系统]: 用户刚刚离开，现在已经重新接入对话。')
else:
    import os; old='_治理日志/_dialogue_history.log'; new=os.path.splitext(old)[0]+'_old'+os.path.splitext(old)[1]; os.replace(old, new) if os.path.exists(old) else None
    dialogue_count =1

stats_reg={ '/':{ 'msg':'默认模式（对话分析）'} ,\
                '/c':{ 'msg': '程序开发模式，程序开发后会自动测试'} ,\
                 '/ct':{ 'msg': '程序和文本编辑模式，写入文件'}  }
if __name__ == "__main__":
    #####守护进程区。
    target_script = os.path.abspath("_摘要中枢\\_目录更新自动生成监视.py")
    start_daemon(target_script=target_script, main_pid=os.getpid())
    #####
    time.sleep(1)
    """主对话程序：连续对话并记录完整日志"""
    stat='/'
    # 初始化日志结构
    dialog_log = {
        "start_time": datetime.now().isoformat(),
        "conversations": []
    }
    while True:
        # 获取用户输入
        err=''#记录错误信息
        
        if IS_CMD:#cmd上色
            print(Fore.YELLOW + f"\n[模式:{stat} ][用户][{dialogue_count}轮]: ", end="")
            user_input = input()
        else:
            user_input=input(f"\n[模式:{stat} ][用户][{dialogue_count}轮]: ") 
        if user_input in stats_reg.keys():
            stat=user_input
            print(f"[系统]: 进入{stats_reg[stat]['msg']}")
            continue
        user_input =user_input.strip() 
        if user_input.lower() in ['exit', 'quit', '退出']:
            print("对话结束，正在保存日志...")
            break
        if not user_input:
            print("输入不能为空，请重新输入")
            continue
        # 记录用户消息（带时间戳）
        dialogue_count += 1
        user_entry = {
            "role": "user",
            "content": user_input,
            "timestamp": datetime.now().isoformat()
        }
        # 调用AI API
        ###########
        if stat in ['/c','/ct']:#代码文本书写模式
            if stat=='/c':
                code_prmt ='现在，你在程序代码编辑模式，请按照我当前的要求，回答json输出。注意要符合JSON_Schema中规定的要求'
            elif stat=='/ct':
                code_prmt ='现在，你在代码或文本生成模式，请按照我当前的要求，回答json输出。注意要符合JSON_Schema中规定的要求'
            user_input =user_input+code_prmt
            system_prompt=get_system_prompt(stat,{'user_input':user_input})
            response = call_api(user_input, system_prompt=system_prompt,json_format=True )
            temp=json.loads(response["result"]["answer"])
            try:
                code,description,filename,filepath,timeout = temp["code"],  temp["description"], temp["filename"], temp["filepath"],temp.get("timeout", None)
                temp_path = os.path.join(filepath, filename)
                AI_reply_display = f"=================\n文件路径名称：{temp_path}\n文件描述：{description}\n文件内容：[您可以在后台查看AI生成的内容]\n================="
                print_AI_reply(AI_reply_display,token_usage=response['tokens'])
                if os.path.isfile(temp_path):
                    re = input(f'[系统]: 是否，要将 {temp_path} 覆盖性写入？(y/n): ').strip().lower()
                    if re not in ('y', 'yes'):
                        temp_path = f'_test_code_{datetime.now().strftime("%Y%m%d_%H%M%S")}.py'
                        print(f'[系统]: 未覆盖，新文件已写入：{temp_path}')
                    else:
                        os.rename(temp_path, f"{os.path.join(filepath,'__'+filename)}.bak.{datetime.now().strftime('%Y%m%d_%H%M%S')}")#原文件备份。
                # 统一写文件
                dir_path = os.path.dirname(temp_path)
                if dir_path: os.makedirs(dir_path, exist_ok=True)
                with open(temp_path, 'w', encoding='utf-8') as f: f.write(code)
                print(f'[系统]: 文件写入成功！{temp_path}')
            except Exception as err_new:
                print("[系统]: 发生错误：", traceback.format_exc(),"\n切换到普通对话。")
                err+=str(err_new)
            if stat=='/c' and filename[-3:]==".py" and temp_path==os.path.join(filepath, filename):#原始路径没改变。
                passed=False;retry=1;max_try=3
                while (not passed) and retry<=max_try+1:
                    retry+=1
                    print("[系统]: 现在，对刚写完的python代码进行测试…")
                    py_run_result=run_sandbox(temp_path,timeout=timeout)#拿到运行结果。
                    print(f"[系统]: 现在，程序在一个名为run_sandbox的Python沙盒中运行。该沙盒在独立子进程中执行脚本，控制超时设置为{timeout}秒，并返回三元组(success, stdout, stderr)。其中success表示是否成功执行；stdout为标准输出；stderr为错误信息。目前新生成的程序已运行完成，其结果为{py_run_result}。")
                    temp_input='给出你代码测试结果的评估报告，json格式。'
                    another= {'temp_path':temp_path,'code':code,'py_run_result':py_run_result,'user_input':temp_input}
                    system_prompt=get_system_prompt('in_c_test',another)
                    print(f"[系统]: 现在，调用大模型对代码的测试结果进行评估。")
                    response = call_api(temp_input, system_prompt=system_prompt, json_format=True )
                    print_AI_reply('',token_usage=response['tokens'])
                    temp=json.loads(response["result"]["answer"])
                    passed = bool(temp["if_passed"]) if isinstance(temp["if_passed"], (bool, int)) else str(temp["if_passed"]).strip().lower() in {"true","1","yes","passed","pass"}
                    if (not passed) and retry<=max_try:#测试没通过的情况。
                        print(f"[系统]: 代码测试未通过，由于以下原因：{temp['analysis']}")
                        print(f"[系统]: 现在尝试进行第 {retry} 次生成，最多尝试 {max_try} 次。")
                        another= {'temp_path':temp_path,'code':code,'py_run_result':py_run_result, 'analysis':temp["analysis"], 'user_input':user_input}
                        system_prompt=get_system_prompt('in_c_test_retry',another)
                        response = call_api(user_input, system_prompt=system_prompt, json_format=True )
                        temp=json.loads(response["result"]["answer"])
                        code,description,filename,filepath,timeout = temp["code"],  temp["description"], temp["filename"], temp["filepath"],temp.get("timeout", None)
                        temp_path = os.path.join(filepath, filename)
                        AI_reply_display = f"=================\n文件路径名称：{temp_path}\n文件描述：{description}\n文件内容：[您可以在后台查看AI生成的内容]\n================="
                        print_AI_reply(AI_reply_display,token_usage=response['tokens'])
                        with open(temp_path, 'w', encoding='utf-8') as f: f.write(code)
                        print(f'[系统]: 文件写入成功！{temp_path}')
                if (not passed):
                    print(f"[系统]: 尝试超过限定次数，代码测试未通过，由于以下原因：{temp['analysis']}\n切换到普通对话。")
                else:
                    print(f"[系统]: 程序测试成功，写入成功。")
        else:#普通对话模式
            system_prompt=get_system_prompt('/', {'user_input':user_input})
            user_input = user_input
            response = call_api(user_input, system_prompt=system_prompt)
            AI_reply_display=response["result"].get("answer") if isinstance(response["result"], dict) else response["result"]
            print_AI_reply(AI_reply_display,token_usage=response['tokens'])
        stat='/'#保存代码之后返回默认状态。防止用户下一步在debug中讨论，又误操作成了代码模式。
