from _unifiedAPI import *
from pathlib import Path
from _治理文档.提示词编排器.assemble_full_system_prompt import assemble_prompt
from _治理MCP.run_py_sandbox import run_sandbox
import json
import uuid

ROOT = Path(__file__).resolve().parent
运行测试提示词_文件夹 = ROOT /"_治理文档\提示词编排器\运行测试提示词"
read_not_from_file={"L8_项目文件汇总.txt":None, "L9_用户对话历史.txt":None }
sys_prompt=assemble_prompt(运行测试提示词_文件夹,read_not_from_file)
#run_result=run_sandbox('_文件汇总.py')

def call_api_flash(*args, **kwargs):
    kwargs["model"] = "deepseek-v4-flash"
    return call_api(*args, **kwargs)

'''
及格的设计
1，运行Pyhon文件，收集结果和错误代码。
2，根据错误代码，判断是否写好了？
'''
'''
完美的设计
1，根据历史对话，调用大模型api，问：能不能生成？能生成，再调用大模型api问：明确的测试信息，包括：测试阶段目标，代码功能，测试问题，验收标准，本次测试历史；能生成，不能返回；
2，根据测试信息，历史对话摘要，项目文件信息，调用大模型api，问：修改哪些个文件？再问：每个修改成啥样？一个一个修改。
3，修改完了，运行，看日志，拿到结果。
4，结果出来是了，拿结果和测试信息，调用大模型api，问：通过了吗？没通过超过尝试次数返回，没通过没超过最大尝试次数进入2，通过了返回。
'''
