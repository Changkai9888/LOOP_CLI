from _文件汇总 import scan_directory
from _治理文档.提示词编排器.系统提示词聚合pipeline import assemble_prompt
from pathlib import Path
from _print_AI_reply import print_AI_reply,call_api
import json
#提示词聚合
ROOT = Path(__file__).resolve().parent
def read(file_name):
    with open(file_name, "r", encoding="utf-8") as f:
        log = f.read()#目标流程
    return log

def get_89(required_files_list=[]):
    file_summary = scan_directory(required_files_list=required_files_list)  # 获取文件汇总
    with open('_治理日志/_dialogue_history.log', 'r', encoding='utf-8') as f: dialogue_history = f.read()
    #超过4万字符串，已做切断。
    dialogue_history = '之前过早的对话历史，已做截断。'+dialogue_history[-int(4e4):] if len(dialogue_history) > int(4e4) else dialogue_history
    L8_项目信息汇总=f'\n【目前工程文件汇总】\n以下是整个工程的文件结构及内容，包括路径和具体每个文本文档的信息：\n {file_summary}\n'
    return  dialogue_history, L8_项目信息汇总

def get_system_prompt_step2(stat='/', another=None):#这个系统提示词。another是一个dict表示可以传入的其他信息
    dialogue_history, L8_项目信息汇总=get_89(another['required_files_list'])
    read_not_from_file={"L8_项目信息汇总.txt":L8_项目信息汇总, "L9_用户对话历史.txt":dialogue_history }
    if stat=='/c':
        提示词_文件夹 = ROOT /"_治理文档\提示词编排器\主对话提示词\程序开发模式"
    elif stat=='/ct':
        提示词_文件夹 = ROOT /"_治理文档\提示词编排器\主对话提示词\文本写入状态"
    elif stat=='/':
        提示词_文件夹 = ROOT /"_治理文档\提示词编排器\主对话提示词\原始对话状态"
    elif stat=='in_c_test':
        提示词_文件夹 = ROOT /"_治理文档\提示词编排器\运行测试提示词\测试报告生成"
        L8_项目信息汇总=L8_项目信息汇总+f"\n【程序的运行结果】\n 目标程序为：{another['temp_path']}, \n代码原文为：{another['code']}, \n运行结果为：{another['py_run_result']}"
        read_not_from_file={"L8_项目信息汇总.txt":L8_项目信息汇总, "L9_用户对话历史.txt":dialogue_history[-int(5e3):] if len(dialogue_history) > int(5e3) else dialogue_history }
    elif stat=='in_c_test_retry':
        提示词_文件夹 = ROOT /"_治理文档\提示词编排器\运行测试提示词\程序重新改写"
        L8_项目信息汇总=L8_项目信息汇总+f"\n【程序的运行结果】\n 目标程序为：{another['temp_path']}, "+\
                                       "\n代码原文为：{another['code']}, \n运行结果为：{another['py_run_result']} \n【程序测试评估结果为】\n未通过测试！"+\
                                       "\n【未通过原因及修改建议】\n该程序未通过测试的原因及修改建议为：{another['analysis']} "
        read_not_from_file={"L8_项目信息汇总.txt":L8_项目信息汇总, "L9_用户对话历史.txt":dialogue_history[-int(5e3):] if len(dialogue_history) > int(5e3) else dialogue_history }
    return assemble_prompt(提示词_文件夹, read_not_from_file)


def get_system_prompt(stat='/', another=None):#这个系统提示词。another是一个dict表示可以传入的其他信息
    dialogue_history, L8_项目信息汇总=get_89()
    提示词_文件夹 = ROOT /"_治理文档\提示词编排器\提示词裁剪"
    stat_dict={ '/c':'目前AI是负责写程序和运行代码的。',\
    '/ct':'目前AI是负责编辑文本文件的。',\
    '/':'目前AI是负责深度分析和对话。',\
    'in_c_test':'目前AI是负责程序测试运行的。',\
    'in_c_test_retry':'目前AI是负责修改程序中运行的错误。'}
    system_prompt=read(提示词_文件夹/ "1.txt")+'\n【用户本次提问内容为】\n{another["user_input"]}'+\
    '\n【目前AI所处的工作状态】\n{stat_dict[stat]}'+\
    L8_项目信息汇总+dialogue_history
    print('AI正在生成需要详细阅读的文件列表。')
    response = call_api(f'返回json格式。\n{another["user_input"]}', system_prompt=system_prompt,json_format=True )
    required_files_list=json.loads(response["result"]["answer"])['required_files_list']
    print(required_files_list)
    print(response['tokens'])
    another['required_files_list']=required_files_list
    return get_system_prompt_step2(stat, another=another)
