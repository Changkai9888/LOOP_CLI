from unifiedAPI import *
def call_api_flash(*args, **kwargs):
    kwargs["model"] = "deepseek-v4-flash"
    return call_api(*args, **kwargs)

import json
import uuid

def load_planner_system_prompt():
    BASE = "提示词文档"
    prompt = json.load(open(f"{BASE}/任务规划系统提示词.json", encoding="utf-8"))["definition"]
    schema = json.dumps(json.load(open(f"{BASE}/任务拆解格式化.json", encoding="utf-8"))["definition"],
        ensure_ascii=False, indent=2)
    return prompt + "\n\nJSON Schema：\n" + schema

PLANNER_SYSTEM_PROMPT = load_planner_system_prompt()

def route_to_plan(user_input):
    """
    一次性调用 flash：
    - 输入：用户自然语言
    - 输出：结构化任务规划（JSON）
    """

    system_prompt = PLANNER_SYSTEM_PROMPT

    response = call_api_flash(
        user_input=user_input,
        system_prompt=system_prompt,
        json_format=True
    )

    try:
        plan = json.loads(response["result"]["answer"])
    except Exception:
        # fallback：最小可用计划
        plan = {
            "task_id": str(uuid.uuid4()),
            "user_goal": user_input,
            "task_type": "simple_chat",
            "sub_tasks": [
                {
                    "step": 1,
                    "type": "chat",
                    "description": "模型直接回复用户",
                    "depends_on": []
                }
            ]
        }

    return plan
#####
import pprint
def show_plan(plan):
    pprint.pprint(plan, sort_dicts=False, width=120)
    print('###########')
    return plan
if __name__=='__main__':
    show_plan(route_to_plan('把大象放冰箱里，总共分几步？'))
