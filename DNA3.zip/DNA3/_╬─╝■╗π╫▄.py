import os,json
'''
生成目录结构，按现值的大小，每个文件提取头部一小段。
文件在限制的大小内已经完整提取了，则不需要摘要。
如果没有完整提取这个文件，摘要知识库里去寻找文件的摘要，用文件开头加摘要的形式返回。
'''
def read(file_name):
    with open(file_name, "r", encoding="utf-8") as f:
        log = f.read()#目标流程
    return log
def scan_directory(max_size=2,required_files_list=[]):#截取文本文件头部信息的长度,单位kb，如果文本本身没有超过这个大小限制，则返回全文。
    # 初始化输出变量
    dir_tree = ""
    file_contents = ""
    with open(r"_摘要中枢\_abstract.json", "r", encoding="utf-8") as f:
        summary_dict = json.load(f)
        summary_dict={os.path.normpath(old_key): value  for old_key, value in summary_dict.items()}

    # 1. 遍历目录生成树状图和读取内容
    for root, dirs, files in os.walk('.'):
        # --- 过滤逻辑：排除以单/双下划线或点开头的文件/文件夹 ---
        dirs[:] = [d for d in dirs if not d.startswith(('_', '.'))]
        files = [f for f in files if not f.startswith(('_', '.'))]
        
        # 跳过当前脚本自身，避免在内容中被读取导致死循环
        if '__main__.py' in files: files.remove('__main__.py')

        # 计算相对路径层级
        level = root.replace('.', '').count(os.sep)
        indent = ' ' * 4 * level
        
        # 添加目录名到变量1
        dir_name = os.path.basename(root) or '.'
        dir_tree += f"{indent}{dir_name}/\n"

        sub_indent = ' ' * 4 * (level + 1)
        
        # 处理文件内容（变量2）
        for f in files:
            file_path = os.path.join(root, f)
            dir_tree += f"{sub_indent}{f}\n"
            MAX_SIZE_BYTES=max_size * 1024#能够全文显示的文件上限，单位KB。我超过了则以这个大小的前部为输出。
            with open(file_path, 'rb') as fp:
                content_bytes = fp.read(MAX_SIZE_BYTES+1024)
                ovesize = len(content_bytes) >= MAX_SIZE_BYTES
                content = content_bytes[:MAX_SIZE_BYTES].decode('utf-8', errors='ignore')
            # 格式：路径 -> 内容

            file_contents +=f"\n{'-'*30}\n【文件】: {file_path} \n"
            if os.path.normpath(file_path) in summary_dict.keys():
                file_contents +=f"【全文摘要】:\n{summary_dict[os.path.normpath(file_path)]}\n{'-'*30}\n"
            if ovesize:
                if file_path in required_files_list:
                    full_content=read(file_path)
                    file_contents +=f"【全文内容】:\n{full_content}\n{'-'*30}\n"#重点内容全文显示。
                else:
                    file_contents +=f"【节选】: 该文件超过{max_size}KB，且被判定为与本次回答无关的文件，因此不作为完整显示，以下为自动截取前{max_size}KB内容进行显示。\n"+\
                                     f"【节选内容】:\n{content}\n{'-'*30}\n"
            else:
                file_contents +=f"【全文内容】:\n{content}\n{'-'*30}\n"

    # 2. 组合最终输出
    final_output = "========== 目录结构 ==========\n" + dir_tree
    final_output += "\n========== 文件内容 ==========\n" + file_contents
    
    return final_output

if __name__ == "__main__":
    # 执行并保存到文件
    result = scan_directory()
    with open("__文件汇总测试.txt", "w", encoding="utf-8") as f:
        f.write(result)
