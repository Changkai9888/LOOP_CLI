import os, time
from _守护进程 import start_daemon

if __name__ == "__main__":
    target_script = os.path.abspath("_摘要中枢\\_目录更新自动生成监视.py")
    start_daemon(target_script=target_script, main_pid=os.getpid())

    for i in range(20):
        print(f"主进程运行中... {i}")
        time.sleep(1)
