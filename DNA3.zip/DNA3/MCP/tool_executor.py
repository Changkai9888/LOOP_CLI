#!/usr/bin/env python3
"""
MCP 工具执行器
负责加载工具注册表，根据 tool_id 动态调用对应工具函数并返回结果。
支持的工具 ID：read_file、write_file、list_directory、run_code 等。
"""

import json
import logging
import importlib.util
import os
from pathlib import Path
from typing import Dict, Any

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# 当前文件所在目录（MCP/）
MCP_DIR = os.path.dirname(os.path.abspath(__file__))
# 工具注册表路径
REGISTRY_PATH = os.path.join(MCP_DIR, '工具注册表.json')


def load_tool_registry() -> dict:
    """加载工具注册表 JSON 文件"""
    try:
        with open(REGISTRY_PATH, 'r', encoding='utf-8') as f:
            registry = json.load(f)
        logger.info("工具注册表加载成功")
        return registry["definition"]
    except Exception as e:
        logger.error(f"加载工具注册表失败: {e}")
        raise


def find_tool_definition(tool_id: str, registry: dict) -> dict:
    """根据 tool_id 查找工具定义"""
    for tool in registry.get("tools", []):
        if tool.get("tool_id") == tool_id:
            return tool
    return None


def get_tool_module_path(tool_id: str) -> str:
    """
    根据 tool_id 推断工具模块文件路径。
    约定：工具文件位于 MCP/ 目录下，文件名为 <tool_id>_tool.py。
    """
    filename = f"{tool_id}_tool.py"
    return os.path.join(MCP_DIR, filename)


def import_tool_module(tool_id: str) -> Any:
    """动态导入工具模块，返回模块对象"""
    module_path = get_tool_module_path(tool_id)
    if not os.path.exists(module_path):
        raise FileNotFoundError(f"工具模块文件未找到: {module_path}")

    # 构造模块名，避免冲突
    module_name = f"mcp_tool_{tool_id}"
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def execute_tool(tool_id: str, params: dict) -> Dict[str, Any]:
    """
    根据 tool_id 和参数字典执行工具。
    返回工具执行结果字典（与各工具定义的返回格式一致）。
    """
    # 加载注册表
    registry = load_tool_registry()
    tool_def = find_tool_definition(tool_id, registry)
    if not tool_def:
        return {
            "success": False,
            "data": "",
            "error": f"未找到工具定义: {tool_id}",
            "metadata": {}
        }

    # 动态导入模块
    try:
        module = import_tool_module(tool_id)
    except Exception as e:
        logger.error(f"导入工具模块失败: {e}")
        return {
            "success": False,
            "data": "",
            "error": f"工具模块导入错误: {str(e)}",
            "metadata": {}
        }

    # 模块中应存在与 tool_id 同名的函数，如 read_file()
    tool_func = getattr(module, tool_id, None)
    if not tool_func:
        return {
            "success": False,
            "data": "",
            "error": f"模块中未找到函数: {tool_id}",
            "metadata": {}
        }

    # 调用函数，传入参数
    try:
        logger.info(f"执行工具: {tool_id}，参数: {params}")
        result = tool_func(**params)
        logger.info(f"工具 {tool_id} 返回: success={result.get('success')}")
        return result
    except Exception as e:
        logger.error(f"工具执行异常: {e}")
        return {
            "success": False,
            "data": "",
            "error": f"工具执行失败: {str(e)}",
            "metadata": {}
        }


# ---------- 集成测试 ----------
def integration_test():
    """
    测试已实现的文件系统三件套：write_file → read_file → 内容校验 → list_directory
    """
    print("=== MCP 工具执行器集成测试 ===")
    test_file_path = "test_integration.txt"
    test_content = "Hello, MCP Integration Test!"

    # 1. 写入文件
    print("1/3 写入文件...")
    result_write = execute_tool("write_file", {"path": test_file_path, "content": test_content})
    if not result_write.get("success"):
        print(f"写入失败: {result_write['error']}")
        return False
    print(f"写入成功，大小: {result_write['metadata']['size']}")

    # 2. 读取文件
    print("2/3 读取文件...")
    result_read = execute_tool("read_file", {"path": test_file_path})
    if not result_read.get("success"):
        print(f"读取失败: {result_read['error']}")
        return False
    read_content = result_read["data"]
    print(f"读取成功，内容: '{read_content}'")

    # 3. 内容校验
    if read_content != test_content:
        print(f"内容不匹配！ 期望: '{test_content}'，实际: '{read_content}'")
        return False
    print("内容校验通过。")

    # 4. 列举目录（从项目根开始，深度2）
    print("3/3 列举目录...")
    result_list = execute_tool("list_directory", {"root": "../..", "max_depth": 2})
    if not result_list.get("success"):
        print(f"列举失败: {result_list['error']}")
        return False
    print(f"目录列举成功，包含 {result_list['metadata']['dirs_count']} 个目录和 {result_list['metadata']['files_count']} 个文件。")

    print("\n✅ 所有集成测试通过！")
    return True


if __name__ == "__main__":
    # 运行集成测试
    integration_test()
