#!/usr/bin/env python3
"""
MCP Tool: read_file
Tool ID: read_file
Name: 读取文件
Description: 读取本地文件内容，返回文件正文及元信息。
"""

import os
import json
import logging
from pathlib import Path
from typing import Dict

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# 安全限制：最大文件大小（字节）
MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB
# 允许的工作目录（防止路径穿越）
ALLOWED_ROOTS = [os.path.abspath(os.path.dirname(__file__) + '/../..')]  # 项目根目录


def is_path_allowed(path: str) -> bool:
    """检查路径是否在允许的根目录内"""
    abs_path = os.path.abspath(path)
    for root in ALLOWED_ROOTS:
        if abs_path.startswith(os.path.abspath(root)):
            return True
    return False


def detect_encoding(file_path: str) -> str:
    """尝试检测文件编码，失败则返回默认编码"""
    encodings = ['utf-8', 'gbk', 'latin-1']
    for enc in encodings:
        try:
            with open(file_path, 'r', encoding=enc) as f:
                f.read(1024)
            return enc
        except (UnicodeDecodeError, UnicodeError):
            continue
    return 'utf-8'  # 回退


def read_file(path: str) -> Dict[str, object]:
    """
    读取本地文件内容
    
    参数:
        path (str): 文件路径（相对或绝对）
    
    返回:
        dict: {
            "success": bool,
            "data": str,          # 文件内容（成功时）
            "error": str | null,  # 错误信息（失败时）
            "metadata": {
                "path": str,
                "size": int,
                "encoding": str,
                "truncated": bool  # 是否因超过大小阈值被截断
            }
        }
    """
    logger.info(f"read_file called with path: {path}")
    
    # 1. 路径安全检查
    if not is_path_allowed(path):
        return {
            "success": False,
            "data": "",
            "error": "Access denied: file path is outside allowed directories.",
            "metadata": {"path": path, "size": 0, "encoding": "", "truncated": False}
        }
    
    file_path = Path(path)
    if not file_path.exists():
        return {
            "success": False,
            "data": "",
            "error": f"File not found: {path}",
            "metadata": {"path": path, "size": 0, "encoding": "", "truncated": False}
        }
    
    if not file_path.is_file():
        return {
            "success": False,
            "data": "",
            "error": f"Path is not a regular file: {path}",
            "metadata": {"path": path, "size": 0, "encoding": "", "truncated": False}
        }
    
    # 2. 文件大小检查
    file_size = file_path.stat().st_size
    truncated = False
    if file_size > MAX_FILE_SIZE:
        logger.warning(f"File {path} exceeds size limit ({file_size} bytes), will return truncated content.")
        truncated = True
    
    # 3. 编码检测与读取
    encoding = detect_encoding(str(file_path))
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            if truncated:
                # 只读取前 MAX_FILE_SIZE 字符
                content = f.read(MAX_FILE_SIZE)
            else:
                content = f.read()
    except Exception as e:
        return {
            "success": False,
            "data": "",
            "error": f"Failed to read file: {str(e)}",
            "metadata": {"path": path, "size": file_size, "encoding": encoding, "truncated": truncated}
        }
    
    logger.info(f"Successfully read {len(content)} chars from {path}")
    return {
        "success": True,
        "data": content,
        "error": None,
        "metadata": {
            "path": str(file_path.resolve()),
            "size": file_size,
            "encoding": encoding,
            "truncated": truncated
        }
    }


# 独立测试入口
if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        test_path = sys.argv[1]
    else:
        # 如果没有参数，尝试读取自身作为测试
        test_path = __file__
    
    result = read_file(test_path)
    print(json.dumps(result, ensure_ascii=False, indent=2))
