#!/usr/bin/env python3
"""
MCP Tool: write_file
Tool ID: write_file
Name: 写入文件
Description: 将内容写入本地文件。
"""

import os
import json
import logging
from pathlib import Path
from typing import Dict

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# 安全限制：允许的工作目录（防止路径穿越）
ALLOWED_ROOTS = [os.path.abspath(os.path.dirname(__file__) + '/../..')]  # 项目根目录


def is_path_allowed(path: str) -> bool:
    """检查路径是否在允许的根目录内"""
    abs_path = os.path.abspath(path)
    for root in ALLOWED_ROOTS:
        if abs_path.startswith(os.path.abspath(root)):
            return True
    return False


def write_file(path: str, content: str) -> Dict[str, object]:
    """
    将内容写入本地文件
    
    参数:
        path (str): 目标文件路径（相对或绝对）
        content (str): 要写入的文本内容
    
    返回:
        dict: {
            "success": bool,
            "data": str,          # 可能为空（成功时通常为"ok"或写入摘要）
            "error": str | null,  # 错误信息（失败时）
            "metadata": {
                "path": str,
                "size": int,      # 写入后的文件大小
                "encoding": str,  # 使用的编码，默认 utf-8
                "bytes_written": int  # 实际写入的字节数
            }
        }
    """
    logger.info(f"write_file called with path: {path}")
    
    # 1. 路径安全检查
    if not is_path_allowed(path):
        return {
            "success": False,
            "data": "",
            "error": "Access denied: file path is outside allowed directories.",
            "metadata": {"path": path, "size": 0, "encoding": "utf-8", "bytes_written": 0}
        }
    
    file_path = Path(path)
    
    # 2. 确保父目录存在
    try:
        file_path.parent.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        return {
            "success": False,
            "data": "",
            "error": f"Cannot create parent directory: {str(e)}",
            "metadata": {"path": path, "size": 0, "encoding": "utf-8", "bytes_written": 0}
        }
    
    # 3. 写入文件（默认utf-8）
    encoding = 'utf-8'
    try:
        with open(file_path, 'w', encoding=encoding) as f:
            bytes_written = f.write(content)
        file_size = file_path.stat().st_size
        logger.info(f"Successfully wrote {bytes_written} chars ({file_size} bytes) to {path}")
        return {
            "success": True,
            "data": "ok",
            "error": None,
            "metadata": {
                "path": str(file_path.resolve()),
                "size": file_size,
                "encoding": encoding,
                "bytes_written": bytes_written
            }
        }
    except Exception as e:
        return {
            "success": False,
            "data": "",
            "error": f"Failed to write file: {str(e)}",
            "metadata": {"path": path, "size": 0, "encoding": encoding, "bytes_written": 0}
        }


# 独立测试入口
if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 3:
        test_path = sys.argv[1]
        test_content = sys.argv[2]
    else:
        # 默认测试：写入一个测试文件
        test_path = "test_write_output.txt"
        test_content = "Hello, MCP! This is a test write.\nLine 2."
        print("No arguments provided, using default test path and content.")
    
    result = write_file(test_path, test_content)
    print(json.dumps(result, ensure_ascii=False, indent=2))
