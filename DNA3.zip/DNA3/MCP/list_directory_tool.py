#!/usr/bin/env python3
"""
MCP Tool: list_directory
Tool ID: list_directory
Name: 列举目录
Description: 递归列举目录结构，可控制深度。
"""

import os
import json
import logging
from pathlib import Path
from typing import Dict, List, Any

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# 安全限制：允许的工作目录（防止路径穿越）
ALLOWED_ROOTS = [os.path.abspath(os.path.dirname(__file__) + '/../..')]  # 项目根目录


def is_path_allowed(path: str) -> bool:
    """检查路径是否在允许的根目录内"""
    abs_path = os.path.abspath(path)
    for root in ALLOWED_ROOTS:
        if abs_path.startswith(os.path.abspath(root)):
            return True
    return False


def list_directory(root: str, max_depth: int = 3) -> Dict[str, Any]:
    """
    递归列举目录结构
    
    参数:
        root (str): 要列举的根目录路径
        max_depth (int): 最大递归深度，默认3
    
    返回:
        dict: {
            "success": bool,
            "data": list,        # 目录树结构（成功时）
            "error": str | null, # 错误信息（失败时）
            "metadata": {
                "root": str,
                "max_depth": int,
                "files_count": int,
                "dirs_count": int
            }
        }
    """
    logger.info(f"list_directory called with root: {root}, max_depth: {max_depth}")
    
    # 1. 路径安全检查
    if not is_path_allowed(root):
        return {
            "success": False,
            "data": [],
            "error": "Access denied: root path is outside allowed directories.",
            "metadata": {"root": root, "max_depth": max_depth, "files_count": 0, "dirs_count": 0}
        }
    
    root_path = Path(root)
    if not root_path.exists():
        return {
            "success": False,
            "data": [],
            "error": f"Directory not found: {root}",
            "metadata": {"root": root, "max_depth": max_depth, "files_count": 0, "dirs_count": 0}
        }
    
    if not root_path.is_dir():
        return {
            "success": False,
            "data": [],
            "error": f"Path is not a directory: {root}",
            "metadata": {"root": root, "max_depth": max_depth, "files_count": 0, "dirs_count": 0}
        }
    
    # 2. 递归构建树结构
    tree = []
    files_count = 0
    dirs_count = 0
    
    def _recurse(current_path: Path, depth: int):
        nonlocal files_count, dirs_count
        if depth > max_depth:
            return None
        entries = []
        try:
            for entry in sorted(current_path.iterdir(), key=lambda x: (not x.is_dir(), x.name)):
                if entry.name.startswith('.') or entry.name.startswith('_'):
                    continue  # 跳过隐藏文件和下划线开头的文件/目录
                entry_info = {
                    "name": entry.name,
                    "type": "directory" if entry.is_dir() else "file",
                }
                if entry.is_dir():
                    dirs_count += 1
                    children = _recurse(entry, depth + 1)
                    if children is not None:
                        entry_info["children"] = children
                else:
                    files_count += 1
                    entry_info["size"] = entry.stat().st_size
                entries.append(entry_info)
        except PermissionError:
            pass
        return entries
    
    tree = _recurse(root_path, 1)
    
    logger.info(f"Listed {files_count} files and {dirs_count} directories from {root}")
    return {
        "success": True,
        "data": tree,
        "error": None,
        "metadata": {
            "root": str(root_path.resolve()),
            "max_depth": max_depth,
            "files_count": files_count,
            "dirs_count": dirs_count
        }
    }


# 独立测试入口
if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        test_root = sys.argv[1]
        depth = int(sys.argv[2]) if len(sys.argv) > 2 else 3
    else:
        test_root = "."
        depth = 2
        print("No arguments provided, using default root '.' and max_depth 2.")
    
    result = list_directory(test_root, depth)
    print(json.dumps(result, ensure_ascii=False, indent=2))
