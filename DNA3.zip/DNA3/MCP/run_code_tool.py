#!/usr/bin/env python3
"""
MCP Tool: run_code
Tool ID: run_code
Name: 执行代码
Description: 运行 Python / Shell 代码，用于实现计算、自动化操作、数据处理逻辑。
"""

import subprocess
import tempfile
import os
import json
import logging
from pathlib import Path

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# 安全限制
MAX_OUTPUT_LENGTH = 10000  # 最大输出字符数
TIMEOUT = 30  # 执行超时秒数


def run_code(language: str, code: str) -> dict:
    """
    执行 Python 或 Shell 代码，返回输出和状态。
    
    参数:
        language (str): 'python' 或 'shell'
        code (str): 要执行的代码内容
    
    返回:
        dict: {
            "success": bool,
            "data": str,            # 执行输出（成功时）
            "error": str | null,    # 错误信息（失败时）
            "metadata": {
                "language": str,
                "exit_code": int,
                "truncated": bool   # 输出是否被截断
            }
        }
    """
    logger.info(f"run_code called with language: {language}, code length: {len(code)}")
    
    if language not in ('python', 'shell'):
        return {
            "success": False,
            "data": "",
            "error": f"Unsupported language: {language}. Supported: python, shell",
            "metadata": {"language": language, "exit_code": -1, "truncated": False}
        }
    
    try:
        if language == 'python':
            # 将代码写入临时 Python 文件并执行
            with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False, encoding='utf-8') as f:
                f.write(code)
                tmpfile = f.name
            try:
                proc = subprocess.run(
                    ['python', tmpfile],
                    capture_output=True,
                    text=True,
                    timeout=TIMEOUT
                )
            finally:
                # 清理临时文件
                try:
                    os.unlink(tmpfile)
                except OSError:
                    pass
        else:  # shell
            proc = subprocess.run(
                code,
                shell=True,
                capture_output=True,
                text=True,
                timeout=TIMEOUT
            )
    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "data": "",
            "error": f"Execution timed out after {TIMEOUT} seconds",
            "metadata": {"language": language, "exit_code": -1, "truncated": False}
        }
    except Exception as e:
        return {
            "success": False,
            "data": "",
            "error": f"Unexpected error: {str(e)}",
            "metadata": {"language": language, "exit_code": -1, "truncated": False}
        }
    
    exit_code = proc.returncode
    stdout = proc.stdout
    stderr = proc.stderr
    output = stdout
    if stderr:
        output += f"\n[STDERR]\n{stderr}"
    
    truncated = False
    if len(output) > MAX_OUTPUT_LENGTH:
        output = output[:MAX_OUTPUT_LENGTH] + "\n... (output truncated)"
        truncated = True
    
    logger.info(f"Execution finished, exit_code: {exit_code}, output length: {len(output)}")
    return {
        "success": exit_code == 0,
        "data": output,
        "error": None if exit_code == 0 else f"Process exited with code {exit_code}",
        "metadata": {
            "language": language,
            "exit_code": exit_code,
            "truncated": truncated
        }
    }


# 独立测试入口
if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 3:
        lang = sys.argv[1]
        code = sys.argv[2]
    else:
        # 默认测试：Python 代码
        lang = "python"
        code = "print('Hello from run_code tool!')\nprint(2+2)"
        print("No arguments provided, using default Python test.")
    
    result = run_code(lang, code)
    print(json.dumps(result, ensure_ascii=False, indent=2))
