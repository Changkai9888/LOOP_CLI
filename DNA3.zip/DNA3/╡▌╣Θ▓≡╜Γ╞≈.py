#!/usr/bin/env python3
"""新递归拆解器 v3 — 工具优先，强制收敛到工具链
核心改动：
1. 强化 plan_tool_chain 提示词，增加 few-shot 示例，明确合法工具 ID
2. 修复 _validate_tool_chain 中的工具 ID 获取逻辑，确保与注册表一致
3. 优化递归逻辑：当工具链规划失败时，递减 remaining_attempts 并在剩余次数 <=2 时直接降级为 chat
4. 引入全局 API 调用计数器，连续失败超过阈值则提前结束
5. 增加详细调试日志，方便定位问题

修复：
- 修正 TOOLS 加载逻辑：load_tool_registry() 已返回 definition 层，不再重复 .get('definition')
- 增加非空校验，防止工具列表为空导致验证失败
"""

import json
import uuid
import logging
from 任务路由 import route_to_plan
from unifiedAPI import call_api_flash
from MCP.tool_executor import load_tool_registry, find_tool_definition

MAX_RECURSE_DEPTH = 4        # 保留旧常量，用于兼容
DEFAULT_ATTEMPTS = 4         # 默认允许的拆解尝试次数

# 加载工具注册表，转为精简列表用于提示词
TOOL_REGISTRY = load_tool_registry()
# 修复：load_tool_registry() 返回的是 registry["definition"]，直接取 tools 列表
TOOLS = TOOL_REGISTRY.get("tools", [])
if not TOOLS:
    raise RuntimeError("工具注册表加载失败：未找到任何工具定义")

# 全局 API 调用计数器
global_api_call_count = 0
MAX_API_CALLS = 10  # 最多允许10次 API 调用

# 简单缓存：避免对同一 goal 重复调用 API
_GOAL_CACHE = {}

# 配置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def _build_tools_summary():
    """返回工具列表的简洁描述文本，特别强调只能使用这些工具 ID"""
    lines = []
    for t in TOOLS:
        tid = t.get("tool_id", "")
        desc = t.get("description", "")
        params = t.get("parameters", {})
        param_str = ", ".join(f"{k}: {v.get('type', 'string')}" for k, v in params.items())
        lines.append(f"- **{tid}**: {desc}，参数：{param_str if param_str else '无'}")
    # 强制列表
    ids = [t.get("tool_id") for t in TOOLS]
    return "\n".join(lines) + f"\n\n**可用工具 ID 列表（只能使用这些 ID，不得修改或编造）**: {', '.join(ids)}"

def _validate_tool_chain(tools):
    """验证工具链中的 tool_id 是否全部存在于注册表中"""
    valid_ids = {t.get("tool_id") for t in TOOLS}
    logger.debug(f"Valid tool_ids: {valid_ids}")
    for i, t in enumerate(tools):
        tid = t.get("tool_id", "")
        if tid not in valid_ids:
            logger.warning(f"工具链规划生成了无效 tool_id: '{tid}' at position {i}，有效 ID: {valid_ids}")
            return False, tid
    return True, None

def plan_tool_chain(goal: str, remaining_attempts: int) -> list:
    """
    让 Flash 模型规划工具调用序列，尽力组装可执行链。
    返回工具列表 [{tool_id, params}, ...] 或 [] 表示不可行。
    remaining_attempts 影响提示词的强制性：越小越强制。
    """
    global global_api_call_count
    if global_api_call_count >= MAX_API_CALLS:
        logger.warning("达到最大 API 调用次数，直接返回不可行")
        return []

    cache_key = f"plan_{goal}_{remaining_attempts}"
    if cache_key in _GOAL_CACHE:
        logger.info(f"使用缓存结果: {cache_key}")
        return _GOAL_CACHE[cache_key]

    tools_summary = _build_tools_summary()

    # 强制性递增措辞
    if remaining_attempts <= 1:
        force_text = (
            "你已经没有更多拆解机会了，本次规划是最后一次尝试！\n"
            "你必须输出一个可行的工具调用序列，哪怕参数需要合理推测或留空。\n"
            "如果实在无法用任何工具完成，输出 {\"feasible\": false, \"reason\": \"具体原因\"}"
        )
    elif remaining_attempts <= 2:
        force_text = (
            "你只剩下很少的拆解机会，请尽可能将任务分配给现有工具。\n"
            "如果工具可以完成，即使部分参数不完整，也请给出调用（参数可留空或推测）。\n"
            "只有完全不可能时才返回 {\"feasible\": false}。"
        )
    else:
        force_text = (
            "请优先考虑能否用现有工具直接完成任务，推荐输出工具调用序列。\n"
            "如果不能，可以返回 {\"feasible\": false}。"
        )

    # 增加 few-shot 示例
    few_shot_example = """
示例 1：任务“读取文件 config.json”
{"tools": [{"tool_id": "read_file", "params": {"path": "config.json"}}]}

示例 2：任务“列出当前目录并读取 README.md”
{"tools": [{"tool_id": "list_directory", "params": {"root": ".", "max_depth": 1}}, {"tool_id": "read_file", "params": {"path": "README.md"}}]}

示例 3：任务“计算 2+2”
{"tools": [{"tool_id": "run_code", "params": {"language": "python", "code": "print(2+2)"}}]}
"""

    system_prompt = (
        "你是工具链规划器，必须尽力将任务拆解为一个工具调用序列（可包含零个或多个工具）。\n"
        "**必须且只能从以下可用工具列表中选择工具，严禁编造、拼凑或修改工具 ID。**\n"
        "输出严格 JSON 格式：\n"
        "- 若任务可行：{\"tools\": [{\"tool_id\": \"必须为可用工具ID之一\", \"params\": {...}}]}\n"
        "- 若不可行：{\"feasible\": false, \"reason\": \"为什么无法完成\"}\n"
        + force_text +
        "\n" + few_shot_example +
        "\n注意：仅输出 JSON，不要任何额外文字。"
    )

    user_prompt = (
        f"可用工具详情：\n{tools_summary}\n\n"
        f"任务目标：\n{goal}"
    )

    try:
        global_api_call_count += 1
        logger.info(f"调用 plan_tool_chain (第 {global_api_call_count} 次 API)")
        resp = call_api_flash(
            system_prompt=system_prompt,
            user_input=user_prompt,
            temperature=0.1,   # 降低温度减少幻想
            max_tokens=256,
            json_format=True
        )
        content = resp["result"]["answer"]
        logger.debug(f"plan_tool_chain 返回内容: {content}")
        plan = json.loads(content)

        # 检查格式
        if "tools" in plan and isinstance(plan["tools"], list):
            # 转换为旧格式兼容 [{tool_id, params}]
            tools = []
            for t in plan["tools"]:
                if isinstance(t, dict) and "tool_id" in t:
                    tools.append({
                        "tool_id": t["tool_id"],
                        "params": t.get("params", {})
                    })
            # 后置校验：确保所有 tool_id 有效
            valid, bad_id = _validate_tool_chain(tools)
            if not valid:
                logger.warning(f"工具链规划生成了无效 tool_id: {bad_id}，视为不可行")
                _GOAL_CACHE[cache_key] = []
                return []
            logger.info(f"工具链规划成功，生成 {len(tools)} 个工具")
            _GOAL_CACHE[cache_key] = tools
            return tools
        else:
            # 不可行或其他情况
            logger.info("plan_tool_chain 判定为不可行")
            _GOAL_CACHE[cache_key] = []
            return []
    except Exception as e:
        # 解析失败，视为不可行
        logger.error(f"plan_tool_chain 异常: {e}")
        _GOAL_CACHE[cache_key] = []
        return []

# ---------- 节点构造辅助 ----------
def build_task_node(step: int, description: str, depends_on: list,
                    node_type: str = "chat", tool_id: str = None,
                    params: dict = None, children: list = None):
    return {
        "step": step,
        "description": description,
        "depends_on": depends_on,
        "type": node_type,
        "tool_id": tool_id,
        "params": params or {},
        "children": children or []
    }

def _create_tool_nodes(tools: list, base_step: int, depends_on_base: list = None) -> list:
    """将工具列表转化为任务树节点（线性依赖）"""
    nodes = []
    depends_on_base = depends_on_base or []
    for i, t in enumerate(tools):
        step = base_step + i
        deps = []
        if i == 0 and depends_on_base:
            deps = depends_on_base[:]
        elif i > 0:
            deps = [step - 1]   # 依赖前一个工具
        node = build_task_node(
            step=step,
            description=f"调用工具 {t['tool_id']}",
            depends_on=deps,
            node_type="tool",
            tool_id=t["tool_id"],
            params=t.get("params", {})
        )
        nodes.append(node)
    return nodes

# ---------- 核心递归函数 ----------
def _tool_first_dispatch(goal: str, remaining_attempts: int, step_offset: int = 0) -> list:
    """
    内部递归分发器：优先工具链，失败则拆解，深度越深越强制。
    改进：如果工具链失败且剩余尝试次数 <= 2，直接降级为 chat，不再递归拆解。
    """
    global global_api_call_count
    logger.info(f"_tool_first_dispatch: goal='{goal}', remaining_attempts={remaining_attempts}, step_offset={step_offset}")
    
    # 1. 先试工具链规划
    tools = plan_tool_chain(goal, remaining_attempts)
    if tools:
        # 直接构建工具节点（单链）
        return _create_tool_nodes(tools, base_step=step_offset)

    # 2. 工具链不可行，判断是否还有拆解额度
    if remaining_attempts <= 2:  # 剩余次数少，直接降级
        logger.info(f"剩余尝试次数 {remaining_attempts} <= 2，直接降级为 chat")
        return [build_task_node(
            step=step_offset,
            description=goal,
            depends_on=[],
            node_type="fallback_chat"  # 稍后由 finalize_tree 转为 chat
        )]

    # 3. 还有额度，尝试拆解为子任务（使用缓存避免重复规划）
    cache_key = f"route_{goal}"
    if cache_key in _GOAL_CACHE:
        plan = _GOAL_CACHE[cache_key]
    else:
        try:
            if global_api_call_count >= MAX_API_CALLS:
                logger.warning("API 调用次数已达上限，直接降级为 chat")
                return [build_task_node(
                    step=step_offset,
                    description=goal,
                    depends_on=[],
                    node_type="fallback_chat"
                )]
            global_api_call_count += 1
            plan = route_to_plan(goal)
            _GOAL_CACHE[cache_key] = plan
        except Exception as e:
            logger.error(f"route_to_plan 失败: {e}")
            plan = {"sub_tasks": []}
    sub_tasks = plan.get("sub_tasks", [])
    if not sub_tasks:
        # 路由也没拆出子任务，直接降级
        logger.info("route_to_plan 未生成子任务，降级为 chat")
        return [build_task_node(
            step=step_offset,
            description=goal,
            depends_on=[],
            node_type="fallback_chat"
        )]

    # 4. 处理子任务：递归分发，剩余次数减1
    children = []
    child_step = 1
    for task in sub_tasks:
        desc = task["description"]
        # 递归调用，剩余次数减1
        sub_nodes = _tool_first_dispatch(desc, remaining_attempts - 1, step_offset=child_step)
        children.extend(sub_nodes)
        child_step += len(sub_nodes)

    # 5. 用 plan 节点包住所有子节点
    return [build_task_node(
        step=step_offset,
        description=goal,
        depends_on=[],
        node_type="plan",
        children=children
    )]

# ---------- 最终清理 ----------
def finalize_tree(tree: list) -> list:
    """递归转换 fallback_chat 为 chat，处理嵌套 plan"""
    result = []
    for node in tree:
        if node["type"] == "plan":
            node["children"] = finalize_tree(node["children"])
            result.append(node)
        elif node["type"] == "fallback_chat":
            node["type"] = "chat"
            result.append(node)
        else:
            result.append(node)
    return result

# ---------- 公开入口 ----------
def decompose_and_prepare(goal: str) -> list:
    """
    从用户目标出发，生成工具优先的任务树。
    使用 remaining_attempts = DEFAULT_ATTEMPTS。
    重置全局计数器。
    """
    global global_api_call_count
    global_api_call_count = 0  # 重置计数器
    tree = _tool_first_dispatch(goal, DEFAULT_ATTEMPTS)
    return finalize_tree(tree)

# ---------- 独立测试 ----------
if __name__ == "__main__":
    import pprint
    logger.setLevel(logging.DEBUG)  # 测试时显示详细日志
    print("=== 测试新递归拆解器 v3（工具优先） ===")
    # 测试一个简单任务：列出目录
    goal1 = "列出当前目录结构"
    print(f"\n任务：{goal1}")
    tree1 = decompose_and_prepare(goal1)
    pprint.pprint(tree1, sort_dicts=False, width=120)
    print("\n测试完成")
