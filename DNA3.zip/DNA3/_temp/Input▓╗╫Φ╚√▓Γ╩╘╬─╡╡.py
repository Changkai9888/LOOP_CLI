import asyncio
import edge_tts
import os
import time
import multiprocessing
import subprocess
import sys
import signal

def complete_tts_workflow_with_stop(text, voice, output_file, stop_after=5):
    """
    在独立进程中完成整个TTS工作流：生成+播放+5秒后停止
    保持原音色，确保无窗口播放
    """
    try:
        # 1. 生成音频文件
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        async def generate():
            communicate = edge_tts.Communicate(text, voice)
            await communicate.save(output_file)
        
        loop.run_until_complete(generate())
        loop.close()
        
        # 记录生成完成
        with open("tts_log.txt", "a", encoding="utf-8") as f:
            f.write(f"[{time.time()}] TTS生成完成: {output_file}, 大小: {os.path.getsize(output_file)}字节\n")
        
        # 2. 播放音频（确保无窗口）
        if os.path.exists(output_file) and os.path.getsize(output_file) > 0:
            # 关键：使用正确的参数确保ffplay无窗口
            cmd = ['ffplay', '-nodisp', '-autoexit', '-loglevel', 'quiet', output_file]
            
            # Windows隐藏窗口的完整设置
            startupinfo = None
            creationflags = 0
            
            if sys.platform == 'win32':
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = subprocess.SW_HIDE
                creationflags = subprocess.CREATE_NO_WINDOW
            
            # 启动播放进程
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,  # 关键：避免等待标准输入
                startupinfo=startupinfo,
                creationflags=creationflags
            )
            
            with open("tts_log.txt", "a", encoding="utf-8") as f:
                f.write(f"[{time.time()}] 播放进程已启动 (PID: {process.pid})\n")
                f.write(f"[{time.time()}] 计划在{stop_after}秒后停止播放\n")
            
            # 等待指定时间后停止播放
            time.sleep(stop_after)
            
            # 停止播放进程
            if process.poll() is None:  # 进程仍在运行
                if sys.platform == 'win32':
                    process.terminate()  # Windows上使用terminate
                else:
                    process.send_signal(signal.SIGTERM)  # Unix-like系统
                
                # 等待进程结束
                try:
                    process.wait(timeout=2)
                    with open("tts_log.txt", "a", encoding="utf-8") as f:
                        f.write(f"[{time.time()}] 播放已停止（{stop_after}秒后）\n")
                except subprocess.TimeoutExpired:
                    process.kill()  # 强制终止
                    with open("tts_log.txt", "a", encoding="utf-8") as f:
                        f.write(f"[{time.time()}] 播放进程被强制终止\n")
            else:
                with open("tts_log.txt", "a", encoding="utf-8") as f:
                    f.write(f"[{time.time()}] 播放进程已自然结束\n")
        
    except Exception as e:
        with open("tts_log.txt", "a", encoding="utf-8") as f:
            f.write(f"[{time.time()}] 错误: {str(e)}\n")

def main():
    print("=" * 60)
    print("测试方案5增强版: 在temp文件夹中生成MP3 + 播放5秒后停止")
    print("测试目标: 在input()阻塞时，在temp文件夹中生成音频，播放5秒后停止")
    print("=" * 60)
    
    # 清理旧的日志文件
    if os.path.exists("tts_log.txt"):
        os.remove("tts_log.txt")
    
    # 测试参数 - 使用原音色，生成较长的音频（约15秒）
    text = "这是测试方案五增强版的音频，必须使用原来的音色。这段文字比较长，需要大约十五秒钟才能播放完毕。" \
           "我们将测试在播放五秒钟后自动停止的功能，同时主程序仍然卡在输入等待状态。" \
           "如果你听到这段语音在前五秒正常播放，然后在五秒时突然停止，说明测试成功。"
    voice = "zh-CN-XiaoxiaoNeural"  # 保持原音色
    
    # 使用原来的temp文件夹
    temp_dir = "./temp"
    
    # 确保temp文件夹存在
    os.makedirs(temp_dir, exist_ok=True)
    
    # 生成唯一的文件名
    timestamp = int(time.time())
    output_file = os.path.join(temp_dir, f"test_audio_{timestamp}.mp3")
    
    print(f"\n1. 使用原音色: {voice}")
    print(f"2. 音频将保存到: {output_file}")
    print(f"3. 确保播放时无任何窗口")
    print(f"4. 音频长度设计: 约15秒")
    print(f"5. 停止时间点: 播放5秒后自动停止")
    
    # 启动独立进程
    print(f"\n[主进程] 启动独立TTS进程...")
    
    tts_process = multiprocessing.Process(
        target=complete_tts_workflow_with_stop,
        args=(text, voice, output_file, 5)  # 5秒后停止
    )
    tts_process.daemon = True
    tts_process.start()
    
    # 记录启动时间
    start_time = time.time()
    print(f"\n[主进程] TTS进程已启动，开始时间: {time.strftime('%H:%M:%S')}")
    
    print(f"\n[主进程] 现在开始卡在input()...")
    print("=" * 60)
    print("重要: 请不要输入任何内容，直接等待！")
    print("测试预期:")
    print("  1. 音频应该立即开始播放（使用原音色）")
    print("  2. 播放5秒后应该自动停止")
    print("  3. 停止后，你应该听不到后面的音频内容")
    print("  4. 整个过程中无任何窗口出现")
    print("  5. 主程序仍然卡在input()状态")
    print("等待20秒后，可以按回车键退出。")
    print("=" * 60)
    
    # 卡在input()这里
    user_input = input(f"\n[主进程] 当前时间: {time.strftime('%H:%M:%S')} - 卡在input()，请等待并倾听...\n")
    
    elapsed = time.time() - start_time
    print(f"\n[主进程] input()结束，等待了{elapsed:.1f}秒，你输入了: '{user_input}'")
    
    # 等待进程结束
    tts_process.join(timeout=10)
    
    # 显示日志内容
    if os.path.exists("tts_log.txt"):
        print(f"\n[主进程] 日志文件内容:")
        with open("tts_log.txt", "r", encoding="utf-8") as f:
            print(f.read())
    else:
        print(f"\n[主进程] 未找到日志文件")
    
    # 检查文件是否生成
    if os.path.exists(output_file):
        size = os.path.getsize(output_file)
        print(f"\n生成的文件: {output_file}")
        print(f"文件大小: {size} 字节")
        
        if size > 0:
            print("✓ 音频文件生成成功")
            
            # 询问是否清理
            print("\n是否删除测试音频文件？(y/n)")
            choice = input().strip().lower()
            if choice == 'y':
                os.remove(output_file)
                print(f"已删除测试文件: {output_file}")
        else:
            print("✗ 音频文件大小为0")
    else:
        print(f"\n✗ 音频文件未生成")
    
    print("\n测试完成！")
    print("关键验证点:")
    print("1. 是否听到了音频前5秒的正常播放？")
    print("2. 音频是否在第5秒左右突然停止？")
    print("3. 停止后是否听不到后面的内容？")
    print("4. 整个过程中是否有任何窗口出现？")

if __name__ == "__main__":
    if sys.platform == 'win32':
        multiprocessing.freeze_support()
    
    main()
