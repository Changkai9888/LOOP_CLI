from TTS妹子语音 import read_text
import time
result = read_text("从前有个山，山里有个庙，庙里有个和尚在讲故事，讲的是从前有个山，山里又有个庙，庙里又有个和尚。以以此下去无限循环。")
#input()
time.sleep(10)
result = read_text("春风轻拂湖面，水光潋滟如镜。柳丝低垂，鸟鸣清脆，花香随风弥漫，\
仿佛天地都沉浸在温柔的梦境中，心灵也随之宁静悠远。哈哈哈哈")
