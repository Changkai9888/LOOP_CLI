#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
合成系统提示词.py

功能：
把同目录下的 L0-L9 提示词分块文件，按固定协议合成为完整系统提示词。

特点：
1. L0-L9 每一层都稳定存在。
2. 每层都有轻量标题栏，增强段落感和层级感。
3. 每层保留 <<<Lx_BEGIN>>> / <<<Lx_END>>> 边界。
4. 文件不存在或为空时，自动写入占位说明。
5. 不调用大模型，只做文本合成。
6. 块分隔线统一为等号，保持视觉一致。
"""

from pathlib import Path

OUTPUT_FILE = "system_prompt_full.txt"

BLOCKS = [
    ("L0_ROOT_PROTOCOL", "L0_最高协议.txt", "最高协议", ""),
    ("L1_RUNTIME_STATE", "L1_当前状态.txt", "当前运行状态", ""),
    ("L2_CURRENT_TASK_GOAL", "L2_目标.txt", "当前任务目标", ""),
    ("L3_ASSISTANT_ROLE", "L3_AI角色信息.txt", "助手角色", ""),
    ("L4_ASSISTANT_CAPABILITIES", "L4_AI技能信息.txt", "助手能力边界", ""),
    ("L5_USER_PROFILE_AND_AUTHORITY", "L5_用户描述.txt", "用户角色与协作关系", ""),
    ("L6_WORK_RULES", "L6_工作规范.txt", "工作规则", ""),
    ("L7_OUTPUT_CONTRACT", "L7_JSON_Schema.txt", "输出契约", ""),
    ("L8_PROJECT_CONTEXT", "L8_项目信息汇总.txt", "项目相关资料", ""),
    ("L9_DIALOG_HISTORY", "L9_用户对话历史.txt", "历史对话", ""),
]
read_not_from_file={"L8_项目信息汇总.txt":None, "L9_用户对话历史.txt":None }

PLACEHOLDER_PREFIX = "（占位，本层为空。）"

def read_block_content(base_dir: Path, filename: str, placeholder: str,read_not_from_file) -> str:
    
    path = base_dir / filename
    if path.exists() or filename in read_not_from_file.keys():
        if filename in read_not_from_file.keys():
            content = read_not_from_file[filename]
        else:
            content = path.read_text(encoding="utf-8").strip()
        if content:
            return content + "\n"
        else:
            return f"{PLACEHOLDER_PREFIX} {placeholder}\n"
    else:
        return f"{PLACEHOLDER_PREFIX} {placeholder}\n"

def format_block(block_id: str, title: str, priority: int, content: str) -> str:
    separator = "=" * 80
    header = f"{block_id}｜{title}｜priority={priority}"
    return f"{separator}\n{header}\n{separator}\n<<<{block_id}_BEGIN>>>\n{content}<<<{block_id}_END>>>\n"

def assemble_prompt(base_dir = Path(__file__).resolve().parent,read_not_from_file=read_not_from_file) -> str:
    parts = []
    for idx, (block_id, filename, title, placeholder) in enumerate(BLOCKS):
        content = read_block_content(base_dir, filename, placeholder, read_not_from_file)
        parts.append(format_block(block_id, title, idx, content))
        parts.append("\n")
    return "".join(parts)

def main():
    final_prompt = assemble_prompt()
    output_path = Path(__file__).resolve().parent / OUTPUT_FILE
    output_path.write_text(final_prompt, encoding="utf-8")
    print(f"系统提示词已生成: {OUTPUT_FILE}")
    print("L0-L9 块已全部存在，空块占位，分隔线统一为等号。")

if __name__ == "__main__":
    main()
