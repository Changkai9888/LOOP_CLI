---
name: windows-force-kill-child-cleanup
description: 在 Windows 上强杀父进程时确保子进程完全清理的架构方案——使用独立监控进程而非线程
source: auto-skill
extracted_at: '2026-06-03T17:07:41.772Z'
---

## 问题

在 Windows 上，当父进程被 `taskkill /F` 或任务管理器强制终止时，使用**父进程内部线程**来清理子进程是**无效的**。

### 为什么线程方案不行

1. `taskkill /F` 发送 `TerminateProcess`，操作系统**立即终止整个进程**
2. 所有线程（包括 `daemon=False` 的线程）瞬间消失
3. **没有机会执行** `finally`、`atexit`、信号处理、清理代码
4. 子进程变成孤儿进程，继续运行

### 错误方案示例

```python
# ❌ 这种方式在强杀时完全无效
def cleanup_thread():
    try:
        while True:
            if not main_alive():
                kill_children()  # 永远不会执行到
            time.sleep(1)
    finally:
        kill_children()  # 强杀时不会执行

t = threading.Thread(target=cleanup_thread, daemon=False)
t.start()
```

## 正确方案：独立监控进程

启动一个**完全独立的 Python 进程**作为监控器，传入父进程 PID 和子进程 PID。

### 架构

```
父进程 (_住.py)
  ├─ 子进程 (_目录更新自动生成监视.py)
  └─ 独立监控进程 (_独立守护.py)  ← 独立 PID，不依赖父进程

当父进程被强杀 → 独立监控进程检测到 → 清理子进程树 → 自己退出
```

### 核心代码

**监控进程** (`_独立守护.py`)：

```python
import psutil
import subprocess
import time
import sys

def kill_tree_psutil(pid):
    """递归杀进程树（从叶子到根）"""
    parent = psutil.Process(pid)
    for child in reversed(parent.children(recursive=True)):
        try:
            child.kill()
        except: pass
    try:
        parent.kill()
    except: pass

def kill_tree_taskkill(pid):
    """taskkill 兜底"""
    subprocess.run(f"taskkill /F /T /PID {pid}", capture_output=True, timeout=3)

def kill_single_hard(pid):
    """Windows API 终极手段"""
    import ctypes
    PROCESS_TERMINATE = 0x0001
    handle = ctypes.windll.kernel32.OpenProcess(PROCESS_TERMINATE, False, pid)
    if handle:
        ctypes.windll.kernel32.TerminateProcess(handle, -1)
        ctypes.windll.kernel32.CloseHandle(handle)

def hard_cleanup(pid):
    """四层清理"""
    kill_tree_psutil(pid)
    time.sleep(0.1)
    kill_tree_taskkill(pid)
    time.sleep(0.1)
    kill_tree_psutil(pid)   # 二次扫描
    time.sleep(0.1)
    kill_single_hard(pid)   # 终极手段

def monitor_child(main_pid, child_pid, target_script):
    while True:
        if not psutil.pid_exists(main_pid):
            # 主进程消失，清理子进程
            if psutil.pid_exists(child_pid):
                hard_cleanup(child_pid)
            # 全系统扫描兜底
            for proc in psutil.process_iter(['pid', 'cmdline']):
                cmdline = ' '.join(proc.info.get('cmdline') or [])
                if target_script in cmdline:
                    try:
                        proc.kill()
                    except: pass
            # 多轮扫描
            for _ in range(3):
                time.sleep(0.2)
                current = psutil.Process(os.getpid())
                for child in current.children(recursive=True):
                    try: child.kill()
                    except: pass
            return
        time.sleep(1)
```

**父进程启动**：

```python
# 启动子进程
if os.name == 'nt':
    CREATE_NEW_PROCESS_GROUP = 0x00000200
    self.proc = subprocess.Popen(
        [sys.executable, target_script],
        creationflags=CREATE_NEW_PROCESS_GROUP,  # 独立进程组
    )

# 启动独立监控进程
self.daemon_proc = subprocess.Popen(
    [sys.executable, "_独立守护.py",
     str(os.getpid()),    # 父进程 PID
     str(self.proc.pid),  # 子进程 PID
     target_script],
    stdout=subprocess.DEVNULL,
    stderr=subprocess.DEVNULL,
)
```

### 关键要点

| 要点 | 说明 |
|------|------|
| 独立进程 | 监控必须是独立 PID，不能是线程 |
| 从叶子杀到根 | `reversed(children)` 先杀孙进程再杀子进程 |
| 多层清理 | psutil → taskkill → psutil二次 → Windows API |
| 全系统扫描 | 按脚本名匹配 cmdline 清理残留 |
| 多轮扫描 | 至少 3 轮，间隔 0.2 秒，确保无遗漏 |
| CREATE_NEW_PROCESS_GROUP | 子进程有独立进程组，方便 taskkill /T |

### 不要做的事

- ❌ 用线程做清理（强杀时不执行）
- ❌ 只用 `atexit`（强杀时不执行）
- ❌ 只用信号处理（强杀时不执行）
- ❌ 先杀父进程再杀子进程（子进程会脱离控制）
- ❌ 只做一轮清理（可能有延迟创建的进程漏掉）
