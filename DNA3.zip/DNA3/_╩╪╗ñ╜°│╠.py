import subprocess
import threading
import time
import os
import sys
import psutil


class WindowsProcessDaemon:
    def __init__(self, main_pid, max_restarts=5, restart_delay=2):
        self.main_pid = main_pid
        self.max_restarts = max_restarts
        self.restart_delay = restart_delay

        self.proc = None
        self.stop_flag = threading.Event()
        self.restart_count = 0
        self.daemon_proc = None  # 独立守护进程

    # =========================================================
    # 🔥 核心：递归杀进程树（比 taskkill 更可靠）
    # =========================================================
    def kill_tree_psutil(self, pid):
        try:
            if not psutil.pid_exists(pid):
                return

            parent = psutil.Process(pid)
            children = parent.children(recursive=True)

            # 先杀子进程（从叶子到根，避免父进程先死导致子进程脱离控制）
            for child in reversed(children):
                try:
                    child.kill()
                except Exception:
                    pass

            # 再杀父进程
            try:
                parent.kill()
            except Exception:
                pass

        except Exception:
            pass

    # =========================================================
    # 兜底：taskkill（防 psutil 异常情况）
    # =========================================================
    def kill_tree_taskkill(self, pid):
        try:
            # /T 表示杀进程树，/F 强制
            subprocess.run(
                f"taskkill /F /T /PID {pid}",
                capture_output=True,
                timeout=3
            )
        except Exception:
            pass

    # =========================================================
    # 暴力单杀：针对特定 PID 的终极手段
    # =========================================================
    def kill_single_hard(self, pid):
        """使用 Windows API 强制终止进程"""
        try:
            import ctypes
            PROCESS_TERMINATE = 0x0001
            handle = ctypes.windll.kernel32.OpenProcess(
                PROCESS_TERMINATE, False, pid
            )
            if handle:
                ctypes.windll.kernel32.TerminateProcess(handle, -1)
                ctypes.windll.kernel32.CloseHandle(handle)
        except Exception:
            pass

    # =========================================================
    # 强力双清理
    # =========================================================
    def hard_cleanup(self, pid):
        self.kill_tree_psutil(pid)
        time.sleep(0.1)
        self.kill_tree_taskkill(pid)
        time.sleep(0.1)
        self.kill_tree_psutil(pid)  # 二次扫描兜底
        time.sleep(0.1)
        self.kill_single_hard(pid)  # 终极手段

    # =========================================================
    # 启动子进程（关键：不要 CREATE_NEW_PROCESS_GROUP）
    # =========================================================
    def start_target(self, target_script):
        self.cleanup_current()

        if not os.path.isfile(target_script):
            raise FileNotFoundError(target_script)

        # 关键：设置 CREATE_NEW_PROCESS_GROUP，让子进程有独立的进程组，方便清理
        if os.name == 'nt':
            CREATE_NEW_PROCESS_GROUP = 0x00000200
            creationflags = CREATE_NEW_PROCESS_GROUP
        else:
            creationflags = 0

        self.proc = subprocess.Popen(
            [sys.executable, target_script],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            creationflags=creationflags,
        )

        # 🔥 启动独立守护进程
        daemon_script = os.path.join(os.path.dirname(__file__), "_独立守护.py")
        if os.path.exists(daemon_script):
            self.daemon_proc = subprocess.Popen(
                [sys.executable, daemon_script,
                 str(self.main_pid),
                 str(self.proc.pid),
                 target_script],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            #print(f"[守护] 独立守护进程已启动: {self.daemon_proc.pid}")
            后台程序简介={os.path.abspath(target_script):"文件自动摘要程序"}
            print(f"[守护] 后台进程已启动: {后台程序简介[target_script]}")

    # =========================================================
    # 清理当前子进程
    # =========================================================
    def cleanup_current(self):
        if self.proc and self.proc.poll() is None:
            self.hard_cleanup(self.proc.pid)
        self.proc = None
        if self.daemon_proc and self.daemon_proc.poll() is None:
            self.daemon_proc.kill()
        self.daemon_proc = None

    # =========================================================
    # 判断主进程是否存活
    # =========================================================
    def main_alive(self):
        return psutil.pid_exists(self.main_pid)

    # =========================================================
    # 主监控循环
    # =========================================================
    def monitor(self, target_script):
        while not self.stop_flag.is_set():

            # 1️⃣ 主进程不存在 → 全部清理 + 自杀
            if not self.main_alive():
                print("[Daemon] 主进程消失，执行最终清理")
                self.shutdown()
                return

            # 2️⃣ 子进程异常退出 → 重启
            if self.proc is None or self.proc.poll() is not None:

                if self.restart_count >= self.max_restarts:
                    print("[Daemon] 达到最大重启次数")
                    return

                self.restart_count += 1
                print(f"[Daemon] 重启子进程 {self.restart_count}/{self.max_restarts}")

                try:
                    self.start_target(target_script)
                except Exception as e:
                    print("[Daemon] 启动失败:", e)

            # 3️⃣ 定期清理残留（关键补丁）
            self.cleanup_zombies()

            time.sleep(1)

    # =========================================================
    # 清理僵尸 / 残留 Python 进程
    # =========================================================
    def cleanup_zombies(self):
        try:
            # 如果进程已经结束但系统没回收
            if self.proc and self.proc.poll() is not None:
                try:
                    self.proc.wait(timeout=0.1)
                except Exception:
                    pass

        except Exception:
            pass

    # =========================================================
    # 全部关闭（关键修复点）
    # =========================================================
    def shutdown(self):
        self.stop_flag.set()

        if self.proc:
            self.hard_cleanup(self.proc.pid)

        # 🔥 多轮扫描：清理所有子孙进程
        for _ in range(3):  # 三轮扫描，确保清理彻底
            time.sleep(0.2)
            try:
                current = psutil.Process(os.getpid())
                children = current.children(recursive=True)
                if not children:
                    break
                for child in children:
                    try:
                        child.kill()
                    except Exception:
                        pass
            except Exception:
                pass

        # 🔥 扩大扫描范围：清理所有与目标脚本相关的进程
        try:
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    cmdline = proc.info.get('cmdline') or []
                    cmdline_str = ' '.join(cmdline)
                    if '_目录更新自动生成监视.py' in cmdline_str:
                        proc.kill()
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
        except Exception:
            pass

        # 🔥 终极兜底：再扫一轮所有 Python 进程
        time.sleep(0.3)
        try:
            current = psutil.Process(os.getpid())
            for child in current.children(recursive=True):
                try:
                    self.hard_cleanup(child.pid)
                except Exception:
                    pass
        except Exception:
            pass

        # 🔥 taskkill 兜底
        if self.proc:
            self.kill_tree_taskkill(self.proc.pid)


# =========================================================
# 单例
# =========================================================
_daemon_instance = None


def start_daemon(target_script, main_pid, max_restarts=5):
    global _daemon_instance

    if _daemon_instance:
        return _daemon_instance

    d = WindowsProcessDaemon(
        main_pid=main_pid,
        max_restarts=max_restarts
    )

    t = threading.Thread(
        target=d.monitor,
        args=(target_script,),
        daemon=False  # 关键修复：改为非 daemon，确保主进程退出时线程能执行完整清理
    )
    t.start()

    _daemon_instance = d
    return d
