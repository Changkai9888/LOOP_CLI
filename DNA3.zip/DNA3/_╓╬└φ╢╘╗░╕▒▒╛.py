# -*- coding: utf-8 -*-
from _unifiedAPI import *
import json,traceback, os, time ,sys,psutil
from datetime import datetime
from _文件汇总 import scan_directory
from pathlib import Path
from _治理文档.提示词编排器.assemble_full_system_prompt import assemble_prompt
from _治理MCP.run_py_sandbox import run_sandbox
IS_CMD = psutil.Process(os.getppid()).name().lower()== "cmd.exe"          # ✅ 是否在真实终端（CMD/WT）
if IS_CMD:
    os.system("")          # 激活 CMD 的 ANSI； CmD里设置颜色。
    from colorama import init, Fore, Back, Style
    init(autoreset=True)
def print_cmd(text, color='CYAN', end="\n"):
    if IS_CMD:
        color_list={'CYAN':Fore.CYAN, 'LIGHTGREEN_EX':Fore.LIGHTGREEN_EX}
        print(color_list[color] + text, end=end)
    else:
        print(text)
####
###
def print_AI_reply(AI_reply_display, token_usage):#token_usage=response['tokens']#打印ai回复。
    print_cmd('[AI回答]: ', color='LIGHTGREEN_EX', end='')
    print(AI_reply_display)
    print_cmd(f"[Token使用]: 提示词{token_usage['prompt_tokens']}, 补全{token_usage['completion_tokens']}, 总计{token_usage['total_tokens']}")
    return
###
call_api_old=call_api
def call_api( *args, stat='/', **kwargs):
    #kwargs["model"] = "deepseek-v4-flash"
    print("[AI]: 思考中...")
    response=call_api_old(*args, **kwargs)
    return response

##########
re=input('是否恢复上次的对话记录？(y/n)')
if re.strip().lower() in ('y', 'yes'):
    with open('_治理日志/_dialogue_history.txt', 'r', encoding='utf-8') as f: dialogue_history = f.read()
else:
    dialogue_history = ""
dialogue_count =int((dialogue_history.count("【用户】")+dialogue_history.count("【AI】"))/2)
ROOT = Path(__file__).resolve().parent

def get_system_prompt(stat='/'):#这个系统提示词。
    with open("对话日志/dialogue_history.txt", "r", encoding="utf-8") as f:
        log = f.read()#目标流程
    file_summary = scan_directory()  # 获取文件汇总
    L8_项目信息汇总=f'\n【目前工程文件汇总】\n以下是整个工程的文件结构及内容，包括路径和具体每个文本文档的信息：\n {file_summary}\n'+\
                                f'\n【用户对话日志】\n以下是这个CLI对话系统的运行日志，这是最近一次用户（指的是使用CLI用户）对话日志：\n{log}'
    read_not_from_file={"L8_项目信息汇总.txt":L8_项目信息汇总, "L9_用户对话历史.txt":dialogue_history }
    if stat=='/c':
        提示词_文件夹 = ROOT /"_治理文档\提示词编排器\主对话提示词\文本写入状态"
    else:
        提示词_文件夹 = ROOT /"_治理文档\提示词编排器\主对话提示词\原始对话状态"
    return assemble_prompt(提示词_文件夹,read_not_from_file)

code_prmt ='现在，你在“代码和文本写入”状态，请按照我当前的要求，回答json输出。注意要符合JSON_Schema中规定的要求' 
stats_reg={ '/':{ 'msg':'原始状态值，或刷新状态值。'} ,\
                '/c':{ 'msg': code_prmt} ,\
                  '/f':{ 'msg':'查询，返回当前状态值'} }
DEBUG=1
if __name__ == "__main__":
    """主对话程序：连续对话并记录完整日志"""
    stat='/'
    # 创建_治理日志文件夹
    log_dir = "_治理日志"
    os.makedirs(log_dir, exist_ok=True)
    # 每次启动时新建带时间戳的日志文件
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    timestamp_file = os.path.join(log_dir, f"_dialog_{timestamp}.json")
    latest_file = os.path.join(log_dir, "latest.json")
    # 初始化日志结构
    dialog_log = {
        "start_time": datetime.now().isoformat(),
        "conversations": []
    }
    print(f"AI对话系统已启动")
    print(f"时间戳日志: {timestamp_file}")
    print(f"最新日志: {latest_file}")
    print("输入 'exit' 或 'quit' 结束对话\n")
    while True:
        # 获取用户输入
        err=''#记录错误信息
        if IS_CMD:#cmd上色
            print(Fore.YELLOW + f"\n[模式:{stat} ][用户][{dialogue_count}轮]: ", end="")
            user_input = input()
        else:
            user_input=input(f"\n[模式:{stat} ][用户][{dialogue_count}轮]: ")
        if user_input=='/':
            stat=user_input
            print("状态刷新，回到初始状态：'/'。")
            continue
        elif user_input=='/c':
            stat=user_input
            print("进入代码生成模式")
            continue
        elif user_input=='/f':
            print('当前状态为：', stat, stats_reg[stat])
            continue
        user_input =user_input.strip() 
        if user_input.lower() in ['exit', 'quit', '退出']:
            print("对话结束，正在保存日志...")
            break
        if not user_input:
            print("输入不能为空，请重新输入")
            continue
        # 记录用户消息（带时间戳）
        user_entry = {
            "role": "user",
            "content": user_input,
            "timestamp": datetime.now().isoformat()
        }
        # 调用AI API
        
        if stat=='/c':#代码文本书写模式
            user_input =user_input+stats_reg[stat]['msg']
            system_prompt=get_system_prompt(stat)
            response = call_api(user_input, system_prompt=system_prompt, model="deepseek-v4-pro",json_format=True )
            temp=json.loads(response["result"]["answer"])
            try:
                code,description,filename,filepath = temp["code"],  temp["description"], temp["filename"], temp["filepath"]
                temp_path = os.path.join(filepath, filename)
                AI_reply_display=f'''\n=================
                    代码路径名称：{temp_path}
                    代码描述：{description}
                    代码内容：[您可以在后台查看AI生成的代码内容]
                    =================\n'''
                print_AI_reply(AI_reply_display,token_usage=response['tokens'])
                if os.path.isfile(temp_path):
                    re = input(f'是否，要将 {temp_path} 覆盖性写入？(y/n): ').strip().lower()
                    if re not in ('y', 'yes'):
                        temp_path = f'_test_code_{datetime.now().strftime("%Y%m%d_%H%M%S")}.py'
                        print(f'未覆盖，新文件已写入：{temp_path}')
                    else:
                        os.rename(temp_path, f"{os.path.join(filepath,'__'+filename)}.bak.{datetime.now().strftime('%Y%m%d_%H%M%S')}")#原文件备份。
                # 统一写文件
                dir_path = os.path.dirname(temp_path)
                if dir_path: os.makedirs(dir_path, exist_ok=True)
                with open(temp_path, 'w', encoding='utf-8') as f: f.write(code)
                print(f'文件写入成功！')
            except Exception as err_new:
                print("发生错误：", traceback.format_exc(),"\n切换到普通对话。")
                err+=str(err_new)
            stat='/'#保存代码之后返回默认状态。防止用户下一步在debug中讨论，又误操作成了代码模式。
        else:#普通对话模式
            system_prompt=get_system_prompt()
            user_input = user_input
            response = call_api(user_input, system_prompt=system_prompt, model="deepseek-v4-pro")
            AI_reply_display=response["result"].get("answer") if isinstance(response["result"], dict) else response["result"]
            print_AI_reply(AI_reply_display,token_usage=response['tokens'])
        # 获取提示词信息
        user_prompt, system_prompt = response.get("prompt", (user_input, None))  # 从响应中获取提示词，若无则用默认值
        # 记录AI回复（带时间戳）
        ai_entry = {
            "role": "assistant",
            "content": response["result"].get("answer") if isinstance(response["result"], dict) else response["result"],
            "reasoning": response["result"].get("reasoning") if isinstance(response["result"], dict) else None,
            "tokens": response["tokens"],
            "timestamp": datetime.now().isoformat()
        }
        # 新增：更新对话历史变量
        dialogue_count += 1
        dialogue_history += f"\n【用户】({user_entry['timestamp']}): {user_input}\n"
        dialogue_history += f"\n【AI】({ai_entry['timestamp']}): { AI_reply_display }\n"
        if err: dialogue_history += f"\n本轮发生错误信息: ({ai_entry['timestamp']}): {err}\n"
        #超过4万字符串，已做切断。
        dialogue_history = '之前过早的对话历史，已做截断。'+dialogue_history[-int(4e4):] if len(dialogue_history) > int(4e4) else dialogue_history
        # 添加完整对话回合到日志
        conversation_round = {
            "user": user_entry,
            "prompts": {  # 新增：记录提示词
                "user_prompt": user_prompt,  # 最终传给API的用户提示词
                "system_prompt": system_prompt     # 系统提示词
                        },
            "assistant": ai_entry,
            "errption": '本轮发生报错，错误信息为: '+err if err else '本轮未报错。'
        }
        dialog_log["conversations"].append(conversation_round)

        # 同步保存到两个日志文件
        with open(timestamp_file, 'w', encoding='utf-8') as f:
            json.dump(dialog_log, f, ensure_ascii=False, indent=2)
        with open(latest_file, 'w', encoding='utf-8') as f:
            json.dump(dialog_log, f, ensure_ascii=False, indent=2)
        with open('_治理日志/_dialogue_history.txt', 'w', encoding='utf-8') as f:
            f.write(dialogue_history)


