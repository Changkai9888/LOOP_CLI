#!/usr/bin/env python3
"""
新版集成测试脚本：适配工具优先递归拆解器，执行完整 pipeline 并生成结构化日志。
覆盖原 test_pipeline.py。
修复：移除emoji字符，避免Windows控制台GBK编码错误。
"""
import json
import sys
import os
import time
import traceback
from datetime import datetime
from pathlib import Path

# --- 路径设置 ---
SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent
sys.path.insert(0, str(ROOT_DIR))
os.chdir(str(ROOT_DIR))

import 递归拆解器
递归拆解器.DEFAULT_ATTEMPTS = 2  # 减少递归深度，避免超时

from 递归拆解器 import decompose_and_prepare
from 任务执行器 import execute_task_tree
from unifiedAPI import call_api as original_call_api, call_api_flash as original_call_api_flash

QUESTIONS_FILE = SCRIPT_DIR / "测试问题.txt"
LOG_FILE = SCRIPT_DIR / f"test_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"

# 全局 Token 统计
TOKEN_USAGE = {
    "prompt_tokens": 0,
    "completion_tokens": 0,
    "total_tokens": 0
}

def _merge_tokens(tokens_dict):
    for key in TOKEN_USAGE:
        TOKEN_USAGE[key] += tokens_dict.get(key, 0)

def call_api_with_token(*args, **kwargs):
    result = original_call_api(*args, **kwargs)
    if 'tokens' in result:
        _merge_tokens(result['tokens'])
    return result

def call_api_flash_with_token(*args, **kwargs):
    result = original_call_api_flash(*args, **kwargs)
    if 'tokens' in result:
        _merge_tokens(result['tokens'])
    return result

# 注入 token 统计
import unifiedAPI
unifiedAPI.call_api = call_api_with_token
unifiedAPI.call_api_flash = call_api_flash_with_token

import 递归拆解器
import 任务执行器
递归拆解器.call_api_flash = call_api_flash_with_token
任务执行器.call_api_flash = call_api_flash_with_token

def log_print(msg: str):
    """同时输出到控制台和日志文件，并处理编码问题"""
    try:
        # 尝试直接打印，若控制台编码不支持则使用安全形式
        print(msg)
    except UnicodeEncodeError:
        # 处理无法编码的字符（如emoji），替换为类似字符或忽略
        safe_msg = msg.encode(sys.stdout.encoding, errors='replace').decode(sys.stdout.encoding)
        print(safe_msg)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(msg + "\n")

def print_tree(nodes, indent=0):
    """递归打印任务树，适配新拆解器结构，使用纯文本标记代替emoji"""
    prefix = "  " * indent
    for n in nodes:
        ntype = n.get("type", "?")
        desc = n.get("description", "")
        tool_id = n.get("tool_id", "")
        children = n.get("children", [])
        status = n.get("status", "")
        if status == "missing_capability":
            log_print(f"{prefix}[WARN] [{status}] {desc} (reason: {n.get('error', '')})")
        elif ntype == "tool":
            log_print(f"{prefix}[TOOL] [{ntype}] {desc} (工具: {tool_id})")
        elif ntype == "plan":
            log_print(f"{prefix}[PLAN] [{ntype}] {desc}")
        else:
            log_print(f"{prefix}[{ntype}] {desc}")
        if children:
            print_tree(children, indent + 1)

def main():
    if not QUESTIONS_FILE.exists():
        log_print("[ERROR] 测试问题文件未找到: " + str(QUESTIONS_FILE))
        return
    with open(QUESTIONS_FILE, "r", encoding="utf-8") as f:
        questions = [line.strip() for line in f.readlines() if line.strip()]
    if not questions:
        log_print("[ERROR] 测试问题文件为空")
        return

    # 默认测试第1条，可传参数指定序号
    test_index = 0
    if len(sys.argv) > 1:
        try:
            num = int(sys.argv[1])
            if 1 <= num <= len(questions):
                test_index = num - 1
            else:
                log_print(f"[WARN] 问题序号无效 (1-{len(questions)})，默认测试第1条")
        except ValueError:
            log_print("[WARN] 参数错误，默认测试第1条")
    else:
        log_print(f"[INFO] 未指定问题序号，默认测试第1条（共{len(questions)}条可用）")

    q = questions[test_index]
    # 去掉可能的序号前缀
    question_text = q.split(". ", 1)[1] if ". " in q else q

    log_print(f"{'='*60}")
    log_print(f"[TEST] 测试问题: {question_text}")
    log_print(f"[LOG] 日志文件: {LOG_FILE}")
    log_print(f"{'='*60}")

    # 阶段1: 任务拆解
    log_print(f"\n[PHASE1] 任务拆解（新版递归拆解器）\n" + "-"*40)
    try:
        task_tree = decompose_and_prepare(question_text)
        log_print(f"[OK] 拆解完成，生成 {len(task_tree)} 个顶层子任务")
        print_tree(task_tree)
        log_print(f"[TOKENS] 拆解阶段 Token 消耗 (累计): "
                  f"提示词 {TOKEN_USAGE['prompt_tokens']}, "
                  f"补全 {TOKEN_USAGE['completion_tokens']}, "
                  f"总计 {TOKEN_USAGE['total_tokens']}")
    except Exception as e:
        log_print(f"[FAIL] 拆解失败: {e}")
        log_print(traceback.format_exc())
        return

    # 阶段2: 任务执行
    log_print(f"\n[PHASE2] 任务执行（执行调度器）\n" + "-"*40)
    try:
        result = execute_task_tree(task_tree, context=question_text)
        overall = result.get("overall_status", "unknown")
        steps = result.get("steps", [])
        success_count = sum(1 for s in steps if s["status"] == "success")
        fail_count = len(steps) - success_count
        log_print(f"[OK] 执行完成")
        log_print(f"   总体状态: {overall}")
        log_print(f"   成功步骤: {success_count} [OK]")
        log_print(f"   失败步骤: {fail_count} [FAIL]")
        log_print("")
        for step in steps:
            step_num = step["step"]
            stype = step["type"]
            desc = step["description"]
            status = step["status"]
            data = step.get("data", "")
            error = step.get("error")
            icon = "[OK]" if status == "success" else "[FAIL]"
            log_print(f"{icon} 步骤 {step_num}: [{stype}] {desc}")
            if error:
                log_print(f"      错误: {error}")
            else:
                # 数据截断显示
                data_str = str(data)
                if len(data_str) > 300:
                    data_str = data_str[:300] + f"... [截断，总长度{len(data_str)}]"
                if data_str.strip():
                    log_print(f"      数据: {data_str}")
                else:
                    log_print(f"      数据: (空)")
        if fail_count > 0:
            log_print(f"\n[FAIL] 错误详情:")
            for step in steps:
                if step["status"] == "error" and step.get("error"):
                    log_print(f"  步骤{step['step']}: {step['error']}")
        log_print(f"\n[TOKENS] 执行阶段 Token 消耗 (累计): "
                  f"提示词 {TOKEN_USAGE['prompt_tokens']}, "
                  f"补全 {TOKEN_USAGE['completion_tokens']}, "
                  f"总计 {TOKEN_USAGE['total_tokens']}")
    except Exception as e:
        log_print(f"[FAIL] 执行失败: {e}")
        log_print(traceback.format_exc())
        return

    log_print(f"\n{'='*60}")
    log_print(f"[DONE] 测试完成")
    log_print(f"[LOG] 完整日志已保存: {LOG_FILE}")
    log_print(f"[TOKENS] 最终 Token 总消耗: "
              f"提示词 {TOKEN_USAGE['prompt_tokens']}, "
              f"补全 {TOKEN_USAGE['completion_tokens']}, "
              f"总计 {TOKEN_USAGE['total_tokens']}")
    log_print(f"{'='*60}")

if __name__ == "__main__":
    main()
