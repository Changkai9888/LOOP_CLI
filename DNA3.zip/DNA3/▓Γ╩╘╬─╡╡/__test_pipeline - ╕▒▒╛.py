#!/usr/bin/env python3
"""
集成测试脚本：验证递归拆解器 + 任务执行器的完整链路。
读取“测试问题.txt”，逐条执行并打印结果。
支持命令行参数指定测试第几条问题（默认1）。
日志同时输出到控制台和“测试文档/test_log_YYYYMMDD_HHMMSS.txt”。
"""
import json
import time
import sys
import os
from datetime import datetime
from collections import defaultdict
from functools import wraps

# 将项目根目录加入 sys.path，方便模块导入
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT_DIR)

from 递归拆解器 import decompose_and_prepare
from 任务执行器 import execute_task_tree
from unifiedAPI import call_api_flash as original_call_api_flash

# 确定测试问题文件路径（与当前脚本同目录）
QUESTIONS_FILE = os.path.join(os.path.dirname(__file__), "测试问题.txt")

# 日志文件路径（同目录，带时间戳）
LOG_FILE = os.path.join(
    os.path.dirname(__file__),
    f"test_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
)

# 全局 Token 统计
TOKEN_USAGE = {
    "prompt_tokens": 0,
    "completion_tokens": 0,
    "total_tokens": 0
}

def _merge_tokens(tokens_dict):
    """合并 token 统计"""
    for key in TOKEN_USAGE:
        TOKEN_USAGE[key] += tokens_dict.get(key, 0)

def call_api_flash_with_token(user_input, system_prompt=None, **kwargs):
    """包装 call_api_flash，捕获 token 消耗"""
    result = original_call_api_flash(user_input, system_prompt=system_prompt, **kwargs)
    if 'tokens' in result:
        _merge_tokens(result['tokens'])
    return result

# 动态替换模块中的 call_api_flash，让递归拆解器和任务执行器内部调用都会被捕获
import 递归拆解器
递归拆解器.call_api_flash = call_api_flash_with_token
import 任务执行器
任务执行器.call_api_flash = call_api_flash_with_token

def log_print(message: str):
    """同时输出到控制台和日志文件"""
    print(message)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(message + "\n")

def print_tree(nodes, indent=0):
    """递归打印任务树结构"""
    prefix = "  " * indent
    for n in nodes:
        ntype = n.get("type", "?")
        desc = n.get("description", "")
        tool_id = n.get("tool_id", "")
        children = n.get("children", [])
        if tool_id:
            log_print(f"{prefix}├─ [{ntype}] {desc} (工具: {tool_id})")
        else:
            log_print(f"{prefix}├─ [{ntype}] {desc}")
        if children:
            print_tree(children, indent + 1)

def main():
    # 读取测试问题
    if not os.path.exists(QUESTIONS_FILE):
        log_print(f"❌ 测试问题文件未找到: {QUESTIONS_FILE}")
        return
    with open(QUESTIONS_FILE, "r", encoding="utf-8") as f:
        questions = [line.strip() for line in f.readlines() if line.strip()]
    if not questions:
        log_print("❌ 测试问题文件为空")
        return

    # 命令行参数指定测试第几条（默认1）
    test_index = 0  # 转换为列表索引
    if len(sys.argv) > 1:
        try:
            num = int(sys.argv[1])
            if 1 <= num <= len(questions):
                test_index = num - 1
            else:
                log_print(f"⚠️ 问题序号无效 (1-{len(questions)})，默认测试第1条")
        except ValueError:
            log_print("⚠️ 参数错误，默认测试第1条")
    else:
        log_print(f"ℹ️ 未指定问题序号，默认测试第1条（共{len(questions)}条可用）")

    q = questions[test_index]
    # 提取问题文本（去掉序号前缀）
    question_text = q.split(". ", 1)[1] if ". " in q else q

    log_print(f"{'='*60}")
    log_print(f"📌 测试问题: {question_text}")
    log_print(f"📂 日志文件: {LOG_FILE}")
    log_print(f"{'='*60}")

    # ------- 阶段1: 任务拆解 -------
    log_print(f"\n📋 阶段1: 任务拆解（递归拆解器）")
    log_print("-" * 40)
    try:
        task_tree = decompose_and_prepare(question_text)
        log_print(f"✅ 拆解完成，生成 {len(task_tree)} 个顶层子任务")
        print_tree(task_tree)
        log_print(f"📊 拆解阶段 Token 消耗 (累计): "
                  f"提示词 {TOKEN_USAGE['prompt_tokens']}, "
                  f"补全 {TOKEN_USAGE['completion_tokens']}, "
                  f"总计 {TOKEN_USAGE['total_tokens']}")
    except Exception as e:
        log_print(f"❌ 拆解失败: {e}")
        import traceback
        log_print(traceback.format_exc())
        return

    # ------- 阶段2: 任务执行 -------
    log_print(f"\n⚙️ 阶段2: 任务执行（执行调度器）")
    log_print("-" * 40)
    try:
        result = execute_task_tree(task_tree, context=question_text)
        overall = result.get("overall_status", "unknown")
        steps = result.get("steps", [])
        success_count = sum(1 for s in steps if s["status"] == "success")
        fail_count = len(steps) - success_count
        log_print(f"✅ 执行完成")
        log_print(f"   总体状态: {overall}")
        log_print(f"   成功步骤: {success_count} ✅")
        log_print(f"   失败步骤: {fail_count} ❌")
        log_print("")

        for step in steps:
            step_num = step["step"]
            stype = step["type"]
            desc = step["description"]
            status = step["status"]
            data = step.get("data", "")
            error = step.get("error")
            icon = "✅" if status == "success" else "❌"
            log_print(f"{icon} 步骤 {step_num}: [{stype}] {desc}")
            if error:
                log_print(f"      错误: {error}")
            else:
                data_str = str(data)
                if len(data_str) > 300:
                    data_str = data_str[:300] + f"... [截断，总长度{len(data_str)}]"
                if data_str.strip():
                    log_print(f"      数据: {data_str}")
                else:
                    log_print(f"      数据: (空)")
            # 输出子步骤的 token（如果执行器已记录，这里暂时没有，但我们在最后会输出累计）
        if fail_count > 0:
            log_print(f"\n❌ 错误详情:")
            for step in steps:
                if step["status"] == "error" and step.get("error"):
                    log_print(f"  步骤{step['step']}: {step['error']}")
        log_print(f"\n📊 执行阶段 Token 消耗 (累计): "
                  f"提示词 {TOKEN_USAGE['prompt_tokens']}, "
                  f"补全 {TOKEN_USAGE['completion_tokens']}, "
                  f"总计 {TOKEN_USAGE['total_tokens']}")
    except Exception as e:
        log_print(f"❌ 执行失败: {e}")
        import traceback
        log_print(traceback.format_exc())
        return

    log_print(f"\n{'='*60}")
    log_print(f"🏁 测试完成")
    log_print(f"📄 完整日志已保存: {LOG_FILE}")
    log_print(f"📊 最终 Token 总消耗: "
              f"提示词 {TOKEN_USAGE['prompt_tokens']}, "
              f"补全 {TOKEN_USAGE['completion_tokens']}, "
              f"总计 {TOKEN_USAGE['total_tokens']}")
    log_print(f"{'='*60}")

if __name__ == "__main__":
    main()