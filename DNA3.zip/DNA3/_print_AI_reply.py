from _unifiedAPI import *
import json,traceback, os, time ,sys,psutil
from datetime import datetime


def print_cmd(text, color='CYAN', end="\n"):
    if IS_CMD:
        color_list={'CYAN':Fore.CYAN, 'LIGHTGREEN_EX':Fore.LIGHTGREEN_EX}
        print(color_list[color] + text, end=end)
    else:
        print(text)
def print_AI_reply(AI_reply_display, token_usage):#token_usage=response['tokens']#打印ai回复。
    if AI_reply_display:
        print_cmd('[AI回答]: ', color='LIGHTGREEN_EX', end='')
        print(AI_reply_display)
    print_cmd(f"[Token使用]: 提示词{token_usage['prompt_tokens']}, 补全{token_usage['completion_tokens']}, 总计{token_usage['total_tokens']}")
    return
call_api_old=call_api
def call_api( *args, stat='/', **kwargs):
    #kwargs["model"] = "deepseek-v4-flash"
    print("[AI]: 思考中...");
    err=''#记录错误信息
    response=call_api_old(*args, **kwargs)
    return response
