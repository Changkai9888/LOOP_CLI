#!/usr/bin/env python3
"""
任务执行调度器
接收递归拆解器输出的任务树，按依赖顺序驱动工具调用或模型推理，
汇总所有步骤的执行结果并返回结构化状态。不生成面向用户的最终回复。
"""
import json
import logging
from collections import deque
from unifiedAPI import call_api_flash
from MCP.tool_executor import execute_tool

logger = logging.getLogger(__name__)


def flatten_tree(tree: list) -> list:
    """
    将嵌套的任务树展开为线性列表，处理依赖关系。
    将 plan 节点的 children 展开并重新编号步骤，确保执行顺序。
    返回: 扁平化后的节点列表，每个节点包含 global_step 和 depends_on 映射。
    """
    all_nodes = []
    # BFS 遍历树，同时记录父节点依赖
    queue = deque()
    for node in tree:
        queue.append((node, None))  # (节点, 父节点的global_step或None)
    while queue:
        node, parent_step = queue.popleft()
        global_step = len(all_nodes) + 1
        # 复制节点避免修改原树
        flat_node = {
            "global_step": global_step,
            "description": node.get("description", ""),
            "type": node.get("type", "chat"),
            "tool_id": node.get("tool_id"),
            "params": node.get("params", {}),
            "dependencies": []  # 依赖的全局步骤号列表
        }
        # 处理原始 depends_on（相对同层步骤）需要映射为全局步骤
        # 此处简化：依赖父节点（如果有）和同层前序节点
        if parent_step is not None:
            flat_node["dependencies"].append(parent_step)
        # 对于原 depends_on 中的相对步骤，由于树已扁平化，较难直接映射，
        # 我们假设任务树设计时已经保证子任务依赖只在同层，在此仅保留父节点依赖。
        # 如需更精确依赖，可在递归拆解器输出时预计算全局依赖。
        all_nodes.append(flat_node)
        # 如果有子节点，将其加入队列
        children = node.get("children", [])
        if children:
            for child in children:
                queue.append((child, global_step))
    return all_nodes


def execute_tool_node(node: dict) -> dict:
    """执行工具节点，返回结果字典"""
    tool_id = node.get("tool_id")
    params = node.get("params", {})
    if not tool_id:
        return {"success": False, "error": "Missing tool_id", "data": ""}
    try:
        result = execute_tool(tool_id, params)
        return result
    except Exception as e:
        logger.error(f"工具执行异常: {e}")
        return {"success": False, "error": str(e), "data": ""}


def execute_chat_node(node: dict, context: str = "") -> dict:
    """
    处理非工具节点：调用 Flash 模型生成中间推理/分析结果。
    返回与工具节点类似的格式以便统一收集。
    """
    desc = node.get("description", "")
    if not desc:
        return {"success": True, "data": "", "error": None}
    system_prompt = (
        "你是任务执行助手，请根据提供的任务描述和上下文，生成合理的中间分析结果。"
        "只需输出分析结论或处理后的文本，不要额外评论。"
    )
    user_prompt = f"任务描述：{desc}\n上下文：{context}"
    try:
        resp = call_api_flash(
            system_prompt=system_prompt,
            user_input=user_prompt,
            max_tokens=1024,
            temperature=0.1
        )
        answer = resp["result"]["answer"]
        return {"success": True, "data": answer, "error": None}
    except Exception as e:
        return {"success": False, "data": "", "error": str(e)}


def execute_task_tree(task_tree: list, context: str = "") -> dict:
    """
    主入口：执行整个任务树。
    参数:
        task_tree: 递归拆解器输出的任务树列表
        context: 可选的上下文信息（如之前的对话摘要）
    返回: 结构化执行状态
        {
            "overall_status": "completed"|"partial_failure"|"error",
            "steps": [
                {
                    "step": int,           # 全局步骤编号
                    "type": str,           # 节点类型
                    "description": str,
                    "status": "success"|"error",
                    "data": any,           # 执行结果数据
                    "error": str|null      # 错误信息
                }
            ]
        }
    """
    # 1. 扁平化
    flat_nodes = flatten_tree(task_tree)
    
    # 2. 按依赖顺序执行（简单拓扑：这里依赖数量少，用按全局步骤顺序执行，依赖关系仅作记录）
    step_results = []
    overall_success = True
    for node in flat_nodes:
        step_num = node["global_step"]
        description = node["description"]
        node_type = node["type"]
        result = {
            "step": step_num,
            "type": node_type,
            "description": description,
            "status": "success",
            "data": None,
            "error": None
        }
        try:
            if node_type == "tool":
                exec_result = execute_tool_node(node)
            else:
                exec_result = execute_chat_node(node, context)
            result["data"] = exec_result.get("data", "")
            if not exec_result.get("success", False):
                result["status"] = "error"
                result["error"] = exec_result.get("error", "执行失败")
                overall_success = False
        except Exception as e:
            logger.error(f"节点执行异常 step={step_num}: {e}")
            result["status"] = "error"
            result["error"] = str(e)
            overall_success = False
        step_results.append(result)
    
    # 3. 确定整体状态
    if overall_success:
        status = "completed"
    elif any(r["status"] == "success" for r in step_results):
        status = "partial_failure"
    else:
        status = "error"
    
    return {
        "overall_status": status,
        "steps": step_results
    }


if __name__ == "__main__":
    # 测试：模拟一棵简单任务树
    test_tree = [
        {
            "step": 1,
            "description": "列出当前目录内容",
            "type": "tool",
            "tool_id": "list_directory",
            "params": {"root": ".", "max_depth": 2}
        },
        {
            "step": 2,
            "description": "分析上述目录结构，指出可能的项目类型",
            "type": "chat",
            "children": []
        }
    ]
    result = execute_task_tree(test_tree)
    print(json.dumps(result, ensure_ascii=False, indent=2))
