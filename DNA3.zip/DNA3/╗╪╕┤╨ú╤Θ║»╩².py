from unifiedAPI import *
def call_api_flash(*args, **kwargs):
    kwargs["model"] = "deepseek-v4-flash"
    return call_api(*args, **kwargs)

import json
from datetime import datetime

def meta_check(
    user_input: str,
    dialog_summary: str = "无摘要，当前是首次对话。",
    action_log: str = "无动作，当前是首次执行。",
    task_results: str = "",
    world_state: dict | None = None
) -> dict:
    """
    元校验函数：
    判断当前信息截面下，是否应该直接回复用户，还是进入任务拆解。
    """

    # 1. 构造世界状态（默认包含当前时间）
    if world_state is None:
        world_state = {}

    world_state.setdefault("current_time", datetime.now().isoformat())

    # 2. 系统提示词（强约束，只输出 JSON）
    system_prompt = (
    "你是系统决策器。根据【信息截面】（含对话、操作、结果、世界状态、用户输入）判断：\n"
    "1. 若当前信息已足够直接回复，或无法继续拆解/执行，选 **reply**；\n"
    "2. 若信息不足，需新增子任务/调用工具/改变截面状态才能继续，选 **plan**；\n"
    '3. 不确定时：若为首次判断校验（看到【已执行操作】中为空）优先选 plan，否则如果【已执行操作】中有操作记录，优先选 reply；\n\n'
    "输出严格遵循 JSON Schema：\n"
    "{\n"
    '  "action": "reply" | "plan",\n'
    '  "reason": "判断依据",\n'
    '  "payload": {\n'
    '    "reply_points": "回复要点（仅 reply）",\n'
    '    "reply_temperature": "回复温度（仅 reply）",\n'
    '    "user_goal": "为了回答用户的提问，需要待拆解任务目标（仅 plan）"\n'
    "  }\n"
    "}"
    )

    # 3. 组装用户输入（包含所有上下文）
    user_prompt = (
        f"【对话摘要】\n{dialog_summary}\n\n"
        f"【已执行操作】\n{action_log}\n\n"
        f"【任务结果】\n{task_results}\n\n"
        f"【世界状态】\n{json.dumps(world_state, ensure_ascii=False)}\n\n"
        f"【当前用户输入】\n{user_input}"
    )

    # 4. 调用 Flash（你已有的封装）
    response = call_api_flash(
        system_prompt=system_prompt,
        user_input=user_prompt,
        temperature=0,
        max_tokens=512,
        json_format=True   #
    )

    # 5. 安全解析 JSON（兜底保护）
    try:
        json_str = response["result"]["answer"]  # ✅ 这才是 JSON 字符串
        decision = json.loads(json_str)
        decision['user_input']=user_input
    except (KeyError, json.JSONDecodeError):
        decision = {
            "action": "action_error",
            "reason": "JSON 解析失败或结果缺失，安全兜底",
            "payload": {
                "content": "抱歉，我暂时无法处理这个请求。"
            }
        }

    return decision
def handle_user_request(
    user_input: str,
    dialog_summary: str = "",
    action_log: str = "",
    task_results: str = "",
    world_state: dict | None = None
) -> str | dict:
    """
    对 meta_check 的再封装：
    - action=plan：直接穿透返回
    - action=reply：全量上下文 + 决策建议 → 二次生成最终回复
    """

    # 0️⃣ 构造世界状态（与 meta_check 保持一致）
    if world_state is None:
        world_state = {}
    world_state.setdefault("current_time", datetime.now().isoformat())

    # 1️⃣ 调用元校验
    decision = meta_check(
        user_input=user_input,
        dialog_summary=dialog_summary,
        action_log=action_log,
        task_results=task_results,
        world_state=world_state
    )

    # 2️⃣ plan：直接穿透（不变）
    if decision["action"] == "plan":
        return decision

    # 3️⃣ reply：全量上下文 + 决策建议 → 二次生成
    if decision["action"] == "reply":
        payload = decision.get("payload", {})
        reply_points = payload.get("reply_points", "")
        reply_temperature = payload.get("reply_temperature", 0.1)

        # ✅ 系统提示词：角色 + 约束（不再塞上下文）
        system_prompt = (
            "你是一个友好、自然、具备上下文理解能力的助手。\n\n"
            "你的任务是：结合【历史对话、世界状态、用户当前输入】以及【回复要点】，\n"
            "生成一个**流畅、完整、面向用户的回复**。\n\n"
            "要求：\n"
            "1. 回复必须紧扣用户的原始问题，不答非所问；\n"
            "2. 回复风格自然、口语化，像真人对话；\n"
            "3. 如果回复要点为空，请基于上下文自行组织回答。"
        )

        # ✅ 用户提示词：全量信息（与 meta_check 同构 + 决策建议）
        user_prompt = (
            f"[对话摘要]\n{dialog_summary}\n\n"
            f"[已执行操作]\n{action_log}\n\n"
            f"[任务结果]\n{task_results}\n\n"
            f"[世界状态]\n{json.dumps(world_state, ensure_ascii=False)}\n\n"
            f"[当前用户输入]\n{user_input}\n\n"
            f"[回复要点（仅供参考）]\n{reply_points}"
        )

        # ✅ 二次调用（使用穿透的温度）
        final_reply = call_api(
            system_prompt=system_prompt,
            user_input=user_prompt,
            model="deepseek-v4-pro",
            temperature=reply_temperature,
        )

        # 提取回复文本
        try:
            return final_reply["result"]["answer"]
        except Exception:
            return "抱歉，我暂时无法生成回复。"

    # 4️⃣ 兜底
    return "系统处理异常，请稍后再试。"


if __name__=='__main__':
    print(meta_check('把大象放冰箱里，总共分几步？'))
    print(handle_user_request("把大象放冰箱里，总共分几步？"))
    print(handle_user_request("如何成为一个好的佛教徒修行者？"))
    print(handle_user_request("自驾出游，如何从哈尔滨到五台山？"))
    print(handle_user_request("查询一下明天深圳的天气。"))
    print(handle_user_request("用500字左右介绍一下沈阳"))
