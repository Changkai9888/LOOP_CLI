"""
独立守护进程 - 完全独立于主进程的监控器
当主进程消失时，负责清理所有子进程
"""
import os
import sys
import time
import subprocess
import psutil


def kill_tree_psutil(pid):
    """递归杀进程树"""
    try:
        if not psutil.pid_exists(pid):
            return
        parent = psutil.Process(pid)
        children = parent.children(recursive=True)
        for child in reversed(children):
            try:
                child.kill()
            except:
                pass
        try:
            parent.kill()
        except:
            pass
    except:
        pass


def kill_tree_taskkill(pid):
    """taskkill 兜底"""
    try:
        subprocess.run(f"taskkill /F /T /PID {pid}", capture_output=True, timeout=3)
    except:
        pass


def kill_single_hard(pid):
    """Windows API 强制终止"""
    try:
        import ctypes
        PROCESS_TERMINATE = 0x0001
        handle = ctypes.windll.kernel32.OpenProcess(PROCESS_TERMINATE, False, pid)
        if handle:
            ctypes.windll.kernel32.TerminateProcess(handle, -1)
            ctypes.windll.kernel32.CloseHandle(handle)
    except:
        pass


def hard_cleanup(pid):
    """强力清理"""
    kill_tree_psutil(pid)
    time.sleep(0.1)
    kill_tree_taskkill(pid)
    time.sleep(0.1)
    kill_tree_psutil(pid)
    time.sleep(0.1)
    kill_single_hard(pid)


def monitor_child(main_pid, child_pid, target_script):
    """监控主进程和子进程"""
    print(f"[独立守护] 开始监控 - 主进程:{main_pid}, 子进程:{child_pid}")
    
    while True:
        # 1. 检查主进程是否存活
        main_alive = psutil.pid_exists(main_pid)
        
        if not main_alive:
            print(f"[独立守护] 主进程 {main_pid} 已消失，开始清理...")
            
            # 2. 清理子进程树
            if psutil.pid_exists(child_pid):
                hard_cleanup(child_pid)
                print(f"[独立守护] 已清理子进程 {child_pid}")
            
            # 3. 扫描所有相关进程
            for proc in psutil.process_iter(['pid', 'cmdline']):
                try:
                    cmdline = ' '.join(proc.info.get('cmdline') or [])
                    if target_script in cmdline:
                        print(f"[独立守护] 清理残留: {proc.info['pid']}")
                        proc.kill()
                except:
                    pass
            
            # 4. 多轮扫描兜底
            for _ in range(3):
                time.sleep(0.2)
                current = psutil.Process(os.getpid())
                children = current.children(recursive=True)
                if not children:
                    break
                for child in children:
                    try:
                        child.kill()
                    except:
                        pass
            
            print("[独立守护] 清理完成，退出")
            return
        
        # 5. 检查子进程是否还活着
        child_alive = psutil.pid_exists(child_pid)
        if not child_alive:
            print(f"[独立守护] 子进程 {child_pid} 已退出")
            return
        
        time.sleep(1)


if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("用法: python _独立守护.py <主进程PID> <子进程PID> <目标脚本路径>")
        sys.exit(1)
    
    main_pid = int(sys.argv[1])
    child_pid = int(sys.argv[2])
    target_script = sys.argv[3]
    
    monitor_child(main_pid, child_pid, target_script)
