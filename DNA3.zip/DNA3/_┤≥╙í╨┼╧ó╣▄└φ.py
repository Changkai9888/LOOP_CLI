# -*- coding: utf-8 -*-
"""
_打印信息管理.py

核心目标：
    在“不破坏、不污染、不改变主控制台前台显示”的前提下，
    实时旁路记录 Python 主进程控制台中显示出来的文字内容。

能记录：
    - print(...)
    - sys.stdout.write(...)
    - sys.stderr.write(...)
    - traceback.print_exc()
    - logging 默认写到 stderr 的内容
    - 多线程 / asyncio 协程里通过 stdout/stderr 打印的内容
    - input(prompt) 的 prompt
    - 用户在 input() 中输入并由终端回显的文字

重要边界：
    如果某些外部程序/子进程绕过 Python，直接写操作系统 fd=1/fd=2，
    进程内模块想“100%截获”就必须重定向 fd 或套 PTY。
    但重定向 fd 会让 stdout/stderr 不再是原始 TTY，可能影响颜色库、
    交互库、isatty 判断、缓冲策略，这和“不干扰主控制台”冲突。

    所以本文件默认坚持“不干扰主控制台”为最高优先级：
    不劫持 fd，不改 TTY 属性，不把 stdout/stderr 变成 pipe。
    它记录 Python 层能安全旁路复制的所有控制台文字流，
    并专门补记 input 用户输入。
本文件由ChatGPT5生成。
"""
import atexit
import builtins
import io
import os
import re
import sys
import threading
from typing import Optional
from datetime import datetime

_ANSI_RE = re.compile(r"\x1b(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")


class _CaptureBuffer:
    """
    包装 sys.stdout.buffer / sys.stderr.buffer。

    作用：
        捕获 sys.stdout.buffer.write(b"...") 这类二进制写入。
    """

    def __init__(self, original_buffer, manager, encoding_getter):
        self._original_buffer = original_buffer
        self._manager = manager
        self._encoding_getter = encoding_getter

    def write(self, data):
        result = self._original_buffer.write(data)

        if data:
            if isinstance(data, memoryview):
                raw = data.tobytes()
            elif isinstance(data, bytearray):
                raw = bytes(data)
            elif isinstance(data, bytes):
                raw = data
            else:
                raw = bytes(data)

            encoding = self._encoding_getter() or "utf-8"
            text = raw.decode(encoding, errors="replace")
            self._manager._record_from_stream(text, "")

        return result

    def flush(self):
        return self._original_buffer.flush()

    def __getattr__(self, name):
        return getattr(self._original_buffer, name)


class _CaptureTextStream:
    """
    透明包装 sys.stdout / sys.stderr。

    设计原则：
        1. 前台先按原始 stream 写入；
        2. 后台再记录一份；
        3. isatty/fileno/encoding/errors 等全部委托给原始 stream；
        4. 不主动改颜色、不清洗 ANSI、不替换 fd。
    """

    def __init__(self, original_stream, manager, stream_name=""):
        self._original_stream = original_stream
        self._manager = manager
        self._stream_name = stream_name
        self._buffer_proxy = None

    def write(self, text):
        result = self._original_stream.write(text)

        if text:
            self._manager._record_from_stream(str(text), self._stream_name)

        return result

    def writelines(self, lines):
        # 保持原始语义：逐行写前台，同时逐行记录。
        for line in lines:
            self.write(line)

    def flush(self):
        return self._original_stream.flush()

    def isatty(self):
        return self._original_stream.isatty()

    def fileno(self):
        return self._original_stream.fileno()

    def readable(self):
        return False

    def writable(self):
        return True

    def seekable(self):
        try:
            return self._original_stream.seekable()
        except Exception:
            return False

    @property
    def encoding(self):
        return getattr(self._original_stream, "encoding", None)

    @property
    def errors(self):
        return getattr(self._original_stream, "errors", None)

    @property
    def newlines(self):
        return getattr(self._original_stream, "newlines", None)

    @property
    def line_buffering(self):
        return getattr(self._original_stream, "line_buffering", False)

    @property
    def write_through(self):
        return getattr(self._original_stream, "write_through", False)

    @property
    def closed(self):
        return getattr(self._original_stream, "closed", False)

    @property
    def name(self):
        return getattr(self._original_stream, "name", None)

    @property
    def mode(self):
        return getattr(self._original_stream, "mode", None)

    @property
    def buffer(self):
        original_buffer = getattr(self._original_stream, "buffer", None)
        if original_buffer is None:
            return None
        if self._buffer_proxy is None:
            self._buffer_proxy = _CaptureBuffer(
                original_buffer,
                self._manager,
                lambda: self.encoding,
            )
        return self._buffer_proxy

    def __getattr__(self, name):
        return getattr(self._original_stream, name)


class 打印信息管理:
    def __init__(
        self,
        log_dir,
        log_filename,
        *,
        strip_ansi_for_text_log: bool = True,
        ignore_keyboard_interrupt: bool = True,
        encoding: Optional[str] = None,
    ):
        self.log_dir = log_dir
        self.log_filename = log_filename
        self.strip_ansi_for_text_log = strip_ansi_for_text_log
        self.ignore_keyboard_interrupt = ignore_keyboard_interrupt

        self._original_stdout = sys.stdout
        self._original_stderr = sys.stderr
        self._original_stdin = sys.stdin
        self._original_input = builtins.input

        self.encoding = (
            encoding
            or getattr(self._original_stdout, "encoding", None)
            or getattr(self._original_stderr, "encoding", None)
            or "utf-8"
        )

        os.makedirs(self.log_dir, exist_ok=True)
        self.log_path = os.path.join(self.log_dir, self.log_filename)

        self._log_file = None
        self._buffer = io.StringIO()
        self._lock = threading.RLock()
        self._local = threading.local()
        self._is_active = False

        # input(prompt) 专用：
        # 我们手动把 prompt 记入日志，同时允许原生 input(prompt) 正常显示 prompt。
        # 如果原生 input(prompt) 的 prompt 也经过了 sys.stdout.write，
        # 这里会抑制那一次重复记录，避免日志里 prompt 出现两遍。
        self._prompt_suppress_remaining = ""

        # KeyboardInterrupt 过滤专用：
        # stderr 中的 traceback 是分段写出的；为了发现 KeyboardInterrupt 后整段不入日志，
        # 这里会临时暂存 stderr traceback，确认不是 KeyboardInterrupt 后再写入日志。
        self._stderr_traceback_pending = ""

    # ------------------------------------------------------------------
    # 后台记录
    # ------------------------------------------------------------------

    def _clean_for_log(self, text: str) -> str:
        if self.strip_ansi_for_text_log:
            return _ANSI_RE.sub("", text)
        return text
    def _add_timestamp_prefix(self, text: str) -> str:
        prefix = datetime.now().strftime("[%Y-%m-%d %H:%M:%S] ")
        lines = text.splitlines(True)
        return "".join(prefix + line if line.strip() else line for line in lines)
    def _record_direct(self, text: str):
        """直接写后台，不经过前台。"""
        if not text:
            return

        text = self._clean_for_log(text)

        with self._lock:
            # 不长期占用日志文件：每次写入时打开，写完立即关闭。
            # 这样仍然是实时落盘，同时文件在两次写入之间不会被本模块占用。
            with open(self.log_path, "a", encoding="utf-8") as f:
                #f.write(text)
                f.write(self._add_timestamp_prefix(text))
                f.flush()
            self._buffer.write(text)

    def _is_traceback_complete(self, text: str) -> bool:
        lines = [line for line in text.splitlines() if line.strip()]
        if not lines:
            return False

        last = lines[-1].strip()
        if last.startswith("Traceback "):
            return False
        if last.startswith("File "):
            return False
        if last.startswith("^"):
            return False
        if last.startswith("During handling of the above exception"):
            return False
        if last.startswith("The above exception was the direct cause"):
            return False

        # 常见 Python traceback 的最后一行通常是：
        #   ZeroDivisionError: division by zero
        #   KeyboardInterrupt
        #   module.CustomError: message
        return re.match(r"^(?:[A-Za-z_][\\w.]*)(?::|$)", last) is not None

    def _handle_keyboard_interrupt_and_stop(self):
        # 不记录 KeyboardInterrupt traceback，并及时恢复 stdout/stderr/input。
        try:
            self.stop()
        except Exception:
            pass

    def _record_from_stream(self, text: str, stream_name: str = ""):
        """
        stdout/stderr 包装器调用这里。

        处理 input(prompt) 的 prompt 去重：
            - input 包装器会先手动记录 prompt；
            - 如果原生 input(prompt) 又通过 sys.stdout 写 prompt，
              这里识别并跳过这段 prompt，避免重复。

        处理 KeyboardInterrupt：
            - 默认开启；
            - 如果 stderr traceback 中发现 KeyboardInterrupt，整段 traceback 不写入日志；
            - 发现后自动执行 stop()，释放捕获器。
        """
        if not text:
            return

        with self._lock:
            rem = self._prompt_suppress_remaining

            if rem:
                if text == rem:
                    self._prompt_suppress_remaining = ""
                    return

                if rem.startswith(text):
                    self._prompt_suppress_remaining = rem[len(text):]
                    return

                if text.startswith(rem):
                    self._prompt_suppress_remaining = ""
                    text = text[len(rem):]
                    if not text:
                        return
                else:
                    # 不匹配说明这不是 input prompt 的那次写入。
                    # 不再继续抑制，避免误吞后续正常输出。
                    self._prompt_suppress_remaining = ""

        if self.ignore_keyboard_interrupt and stream_name == "stderr":
            # 单独的 KeyboardInterrupt 行也直接忽略并退出捕获。
            if "KeyboardInterrupt" in text and not self._stderr_traceback_pending:
                self._handle_keyboard_interrupt_and_stop()
                return

            if self._stderr_traceback_pending or "Traceback (most recent call last):" in text:
                self._stderr_traceback_pending += text

                if "KeyboardInterrupt" in self._stderr_traceback_pending:
                    self._stderr_traceback_pending = ""
                    self._handle_keyboard_interrupt_and_stop()
                    return

                if self._is_traceback_complete(self._stderr_traceback_pending):
                    pending = self._stderr_traceback_pending
                    self._stderr_traceback_pending = ""
                    self._record_direct(pending)
                    return

                return

        self._record_direct(text)

    # ------------------------------------------------------------------
    # input 透明包装
    # ------------------------------------------------------------------

    def my_input(self, prompt=""):
        """
        透明替代 builtins.input。

        为什么必须包装 input：
            用户键盘输入的终端回显不属于 stdout/stderr，
            所以无法靠 stdout/stderr Tee 捕获。
            input 返回后，把用户输入补写到后台日志，才能还原控制台文字版。

        前台行为：
            prompt 仍然交给原生 input(prompt)；
            用户输入仍然由终端自然回显；
            本函数绝不把用户输入再次写到前台。
        """
        prompt_text = "" if prompt is None else str(prompt)

        if prompt_text:
            # 手动记录 prompt，保证日志一定有 prompt。
            self._record_direct(prompt_text)

            # 如果原生 input(prompt) 的 prompt 也被 stdout wrapper 捕获，
            # 则在 _record_from_stream 中抑制掉那一次重复记录。
            with self._lock:
                self._prompt_suppress_remaining = prompt_text

        try:
            user_text = self._original_input(prompt)
        finally:
            # 如果 input 抛异常，比如 Ctrl+C/EOF，
            # 清掉 prompt 抑制状态，避免误吞后续输出。
            with self._lock:
                self._prompt_suppress_remaining = ""

        # 用户输入已经由终端显示过了，这里只补记后台，不写前台。
        self._record_direct(str(user_text) + "\n")
        return user_text

    # ------------------------------------------------------------------
    # 启停
    # ------------------------------------------------------------------

    def start(self):
        if self._is_active:
            return

        # 不长期打开日志文件，避免运行期间占用文件。
        # 日志仍然实时保存：每次记录时临时打开、写入、立即关闭。
        self._log_file = None

        # 不输出任何启动提示，避免污染主控制台。
        sys.stdout = _CaptureTextStream(self._original_stdout, self, "stdout")
        sys.stderr = _CaptureTextStream(self._original_stderr, self, "stderr")
        builtins.input = self.my_input

        self._is_active = True

    def stop(self):
        if not self._is_active:
            return

        # 先恢复，避免关闭日志时出现递归记录。
        builtins.input = self._original_input
        sys.stdout = self._original_stdout
        sys.stderr = self._original_stderr

        self._is_active = False

        with self._lock:
            # 当前版本不长期持有日志文件句柄，这里只清空状态。
            self._log_file = None

    def get_logs(self):
        with self._lock:
            return self._buffer.getvalue()

    def flush(self):
        try:
            sys.stdout.flush()
        except Exception:
            pass
        try:
            sys.stderr.flush()
        except Exception:
            pass
        # 当前版本每次日志写入都会立即打开、写入、flush、关闭，
        # 因此这里没有长期日志句柄需要 flush。

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.stop()


_sniffer_instance = None


def start_console_capture(
    log_dir,
    log_filename,
    *,
    strip_ansi_for_text_log: bool = True,
    ignore_keyboard_interrupt: bool = True,
):
    """
    启动透明控制台文字记录。

    用法：
        from _打印信息管理 import start_console_capture, get_captured_logs
        start_console_capture("./_治理日志", "test_session.log")

    参数：
        strip_ansi_for_text_log=False
            False：后台日志保留 ANSI 颜色/格式控制码，最接近原始控制台文字流。
            True ：后台日志去掉 ANSI 控制码，但前台颜色完全不受影响。

        ignore_keyboard_interrupt=True
            True ：默认开启。检测到 KeyboardInterrupt traceback 时，不写入该 traceback，并自动停止捕获。
            False：KeyboardInterrupt 按普通 stderr 内容记录。
    """
    global _sniffer_instance

    if _sniffer_instance is None:
        _sniffer_instance = 打印信息管理(
            log_dir,
            log_filename,
            strip_ansi_for_text_log=strip_ansi_for_text_log,
            ignore_keyboard_interrupt=ignore_keyboard_interrupt,
        )
    
    _sniffer_instance.start()
    return _sniffer_instance


def get_captured_logs():
    if _sniffer_instance is None:
        return ""
    return _sniffer_instance.get_logs()


def stop_console_capture():
    global _sniffer_instance
    if _sniffer_instance is not None:
        _sniffer_instance.stop()
