import tiktoken
with open('__文件汇总测试.txt', 'r', encoding='utf-8') as f: dialogue_history = f.read()
def count_tokens(text: str) -> int:
    """使用 cl100k_base 编码器计算 token 数量"""
    enc = tiktoken.get_encoding("cl100k_base")
    return len(enc.encode(text))

if __name__ == "__main__":
    # 将整个对话历史粘贴到这里

    token_count = count_tokens(dialogue_history)
    print(f"Token 数量：{token_count}")
