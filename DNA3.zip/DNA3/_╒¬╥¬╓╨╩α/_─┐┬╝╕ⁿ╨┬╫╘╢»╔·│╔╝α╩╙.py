import os, json, time
from datetime import datetime
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from concurrent.futures import ThreadPoolExecutor, as_completed
import importlib.util,pathlib
spec=importlib.util.spec_from_file_location("_unifiedAPI", pathlib.Path(__file__).parent.parent / "_unifiedAPI.py");
module=importlib.util.module_from_spec(spec);
spec.loader.exec_module(module);
call_api=module.call_api#导入算力
#########
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
THIS_DIR = os.path.abspath(os.path.dirname(__file__))
directory_tree_FILE = os.path.join(THIS_DIR, "_directory_tree.json")
ABSTRACT_FILE = os.path.join(THIS_DIR, "_abstract.json")
def should_ignore(name):
    return name.startswith(("_", "__", "."))

def format_mtime(ts):
    """将 Unix 时间戳格式化为 年-月-日 时:分:秒.毫秒"""
    dt = datetime.fromtimestamp(ts)
    return dt.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]  # 保留毫秒

def generate_dir_structure(root_dir):
    structure = {}
    for dirpath, dirnames, filenames in os.walk(root_dir):
        dirnames[:] = [d for d in dirnames if not should_ignore(d)]
        rel_path = os.path.relpath(dirpath, root_dir)
        structure[rel_path] = {
            "文件夹列表": dirnames,
            "文件列表": [
                {
                    "名称": f,
                    "更新时间": format_mtime(os.path.getmtime(os.path.join(dirpath, f)))
                }
                for f in filenames if not should_ignore(f)
            ]
        }
    return structure

def dir_fresh_dict(file_list):
    a=dict()
    for i in file_list:
        i=os.path.normpath(i)
        a[i]=format_mtime(os.path.getmtime(os.path.join(ROOT_DIR,i)))
    return a

def get_all_file_paths(root_dir):
    paths = []
    for dp, dns, fs in os.walk(root_dir):
        # 过滤掉不需要进入的目录
        dns[:] = [d for d in dns if not should_ignore(d)]
        # 收集文件，同时过滤
        paths.extend(
            os.path.normpath(os.path.relpath(os.path.join(dp, f), root_dir).replace("\\","/"))
            for f in fs if not should_ignore(f)
        )
    return paths


def save_structure(structure):
    with open(directory_tree_FILE, "w", encoding="utf-8") as f:
        json.dump(structure, f, indent=2, ensure_ascii=False)
    print(f"目录结构已更新: {time.ctime()}")

def save_abstract(abstract):
    json.dump(abstract, open(ABSTRACT_FILE, "w", encoding="utf-8"), ensure_ascii=False)
    print(f"已更新摘要: {time.ctime()}")
    
def api_abstract(file):
    content=open(os.path.join(ROOT_DIR,file), "r", encoding="utf-8").read()[:max_read]
    if content=='':
        return file, '当前文件没有任何内容。'
    return file, call_api('为这个文件写摘要，程序型文件字数不要超过300字，普通文本文件，字数不要超过200字。', \
                          f'''\n【主要任务描述】:为以下文字内容写摘要，注意你是写给AI看的。
是大模型API会根据你的摘要，分析他当前遇到的问题是否与这个文件的内容相关，并且判断相关性大小。
特别注意的是：如果判断文件是一个计算机程序的话，则必须描述清楚这个程序的引用依赖，函数接口信息，主要实现功能等。
{"="*30}
【文件内容】
{content}
'''
                          )['result']['answer']

class DirChangeHandler(FileSystemEventHandler):
    def __init__(self):
        self.observer = Observer()
        self.observer.schedule(self, path=ROOT_DIR, recursive=True)
        self.observer.start()
    def on_any_event(self, event):
        if event.src_path.endswith(os.path.basename(directory_tree_FILE)):
            return
        if any(part.startswith(("_", "__", ".")) for part in event.src_path.split(os.sep)):
            return
        print(f"检测到变化: {event.src_path} ({event.event_type})")
        #self.observer.stop()
        #self.observer.unschedule_all()
        update_2_files()
        #self.observer = Observer()
        #self.observer.schedule(self, path=ROOT_DIR, recursive=True)
        #self.observer.start()
        #structure = generate_dir_structure(ROOT_DIR)
        #save_structure(structure)
def abstract_list(file_list):
    abstract=dict()
    with ThreadPoolExecutor() as e:
        for fut  in as_completed({e.submit(api_abstract, file): file for file in file_list}):
            file, summary = fut.result()
            abstract[file] = summary
    return abstract

def update_2_files():#同步更新两个文件。_directory_tree;_abstract
    for i in range(1):#重复查询次数，防止在更新中文件又更新了。
        file_list=get_all_file_paths(ROOT_DIR)#所有文件
        abstract = json.load(open(ABSTRACT_FILE, 'r', encoding='utf-8'))#检测期间文件是不是有变化？有变化的文件重新写摘要吧。
        abstract = {os.path.normpath(k): v for k, v in abstract.items() if os.path.normpath(k) in file_list}#删除多余的
        structure_old=json.load(open(directory_tree_FILE, 'r', encoding='utf-8'))
        structure_old={os.path.normpath(old_key): value  for old_key, value in structure_old.items()}
        structure = dir_fresh_dict(file_list)
        save_structure(structure)
        diff_keys = [key for key in structure if os.path.normpath(key) not in structure_old or structure[key] != structure_old.get(key)]
        if len(diff_keys)==1:
            print(f"更新文件{diff_keys}")
        elif len(diff_keys)>1:
            print(f"更新文件{len(diff_keys)}个")
        abstract_fresh=abstract_list(diff_keys)
        abstract.update(abstract_fresh)
        save_abstract(abstract)
        if len(diff_keys)==0:
            break
    return
if __name__ == "__main__":
    max_read=5000#测试时限制文件读取最大的字符串数。
    print("生成初始目录结构...")
    file_list=get_all_file_paths(ROOT_DIR)#所有文件都要重写
    if not os.path.exists(directory_tree_FILE):#初始化工作文件时。
        save_structure(dir_fresh_dict(file_list))
        abstract=abstract_list(file_list)
        save_abstract(abstract)
    else: #os.path.exists(directory_tree_FILE):
        update_2_files()
    #structure = generate_dir_structure(ROOT_DIR)
    #save_structure(structure)
    print('监督开始…')
    event_handler = DirChangeHandler()
    print(f"开始监控目录: {ROOT_DIR}")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        event_handler.observer.stop()
    event_handler.observer.join()

